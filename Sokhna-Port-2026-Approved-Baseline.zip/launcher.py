"""Windows entry point for Sokhna Port desktop."""
import os, sys
if sys.stdout is None: sys.stdout=open(os.devnull,'w',encoding='utf-8')
if sys.stderr is None: sys.stderr=open(os.devnull,'w',encoding='utf-8')
import backend
if __name__=='__main__':
    raise SystemExit(backend.main())
