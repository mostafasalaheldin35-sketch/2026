#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Company Inspection Desktop local backend.
Stdlib-only: SQLite master DB + physical attachment files + local web server.
"""
from __future__ import annotations

import argparse
import base64
import copy
import ctypes
import datetime as dt
import hashlib
import html
import io
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sqlite3
import sys
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
import zipfile
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

APP_VERSION = "4.8.16.7-R4-DESKTOP"
SCHEMA_VERSION = 4
STORES = ["companies", "items", "attachments", "inspections", "findings", "ncrs", "masterItems", "inspectionMasterItems"]
DEFAULT_PORT = 8766
MAX_JSON_BODY = 1024 * 1024 * 1024  # 1 GiB, local-only server
HEARTBEAT_LOCK = threading.Lock()
LAST_HEARTBEAT = 0.0
HEARTBEAT_STARTED = False


# PyInstaller-safe web asset root. In a frozen build, bundled assets live under sys._MEIPASS.
APP_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
WEB_ROOT = APP_DIR / "app"


def local_appdata() -> Path:
    if os.name == "nt":
        root = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home())
        return Path(root) / "CompanyInspectionDesktop"
    return Path.home() / ".company_inspection_desktop"

CONFIG_DIR = local_appdata()
CONFIG_FILE = CONFIG_DIR / "config.json"


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def safe_part(value: Any, fallback: str = "x") -> str:
    s = str(value or fallback).strip()
    s = re.sub(r"[\\/:*?\"<>|\x00-\x1f]+", "_", s)
    s = re.sub(r"\s+", " ", s).strip(" .")
    return (s[:120] or fallback)


def json_dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def ensure_dirs(root: Path) -> Dict[str, Path]:
    paths = {
        "root": root,
        "database": root / "Database",
        "attachments": root / "Attachments",
        "daily": root / "Backups" / "Daily",
        "weekly": root / "Backups" / "Weekly",
        "manual": root / "Backups" / "Manual",
        "recovery_weekly": root / "Recovery" / "Weekly",
        "recovery_manual": root / "Recovery" / "Manual",
        "excel_default": root / "Excel",
        "logs": root / "Logs",
    }
    for p in paths.values():
        p.mkdir(parents=True, exist_ok=True)
    return paths


def is_fixed_windows_drive(path: Path) -> bool:
    if os.name != "nt":
        return True
    drive = path.resolve().drive
    if not drive:
        return False
    # DRIVE_FIXED = 3. Prevent putting the master DB on USB/removable/network media.
    try:
        return int(ctypes.windll.kernel32.GetDriveTypeW(drive + "\\")) == 3
    except Exception:
        return True


def win_message(text: str, title: str = "Sokhna Port", flags: int = 0x40) -> int:
    if os.name != "nt":
        return 0
    try:
        return int(ctypes.windll.user32.MessageBoxW(None, str(text), str(title), int(flags)))
    except Exception:
        return 0


def browse_for_folder(title: str) -> Optional[Path]:
    """Native Windows folder picker using shell32 only (no Tkinter/external library)."""
    if os.name != "nt":
        return None
    try:
        from ctypes import wintypes

        class BROWSEINFO(ctypes.Structure):
            _fields_ = [
                ("hwndOwner", wintypes.HWND),
                ("pidlRoot", ctypes.c_void_p),
                ("pszDisplayName", wintypes.LPWSTR),
                ("lpszTitle", wintypes.LPCWSTR),
                ("ulFlags", wintypes.UINT),
                ("lpfn", ctypes.c_void_p),
                ("lParam", wintypes.LPARAM),
                ("iImage", ctypes.c_int),
            ]

        display = ctypes.create_unicode_buffer(260)
        bi = BROWSEINFO()
        bi.hwndOwner = None
        bi.pidlRoot = None
        bi.pszDisplayName = ctypes.cast(display, wintypes.LPWSTR)
        bi.lpszTitle = title
        # BIF_RETURNONLYFSDIRS | BIF_EDITBOX | BIF_NEWDIALOGSTYLE
        bi.ulFlags = 0x0001 | 0x0010 | 0x0040
        bi.lpfn = None
        bi.lParam = 0
        bi.iImage = 0
        shell32 = ctypes.windll.shell32
        ole32 = ctypes.windll.ole32
        shell32.SHBrowseForFolderW.argtypes = [ctypes.POINTER(BROWSEINFO)]
        shell32.SHBrowseForFolderW.restype = ctypes.c_void_p
        shell32.SHGetPathFromIDListW.argtypes = [ctypes.c_void_p, wintypes.LPWSTR]
        shell32.SHGetPathFromIDListW.restype = wintypes.BOOL
        ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]
        ole32.CoTaskMemFree.restype = None

        pidl = shell32.SHBrowseForFolderW(ctypes.byref(bi))
        if not pidl:
            return None
        try:
            path_buf = ctypes.create_unicode_buffer(32768)
            ok = shell32.SHGetPathFromIDListW(pidl, path_buf)
            if not ok or not path_buf.value:
                return None
            return Path(path_buf.value).expanduser().resolve()
        finally:
            try:
                ole32.CoTaskMemFree(pidl)
            except Exception:
                pass
    except Exception as e:
        win_message(f"تعذر فتح نافذة اختيار مجلد البيانات.\n\n{e}", flags=0x10)
        return None


def _read_config() -> Dict[str, Any]:
    try:
        if CONFIG_FILE.exists():
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
    except Exception:
        pass
    return {}


def _write_config(data: Dict[str, Any]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _copy_existing_data_if_requested(old_root: Optional[Path], new_root: Path) -> None:
    if not old_root:
        return
    try:
        old_root = old_root.resolve()
        new_root = new_root.resolve()
    except Exception:
        return
    if old_root == new_root or not old_root.exists():
        return
    old_db = old_root / "Database" / "company_master.sqlite3"
    new_db = new_root / "Database" / "company_master.sqlite3"
    if not old_db.exists() or new_db.exists():
        return
    ans = win_message(
        "تم العثور على بيانات سابقة للبرنامج في المكان القديم:\n\n"
        f"{old_root}\n\n"
        "هل تريد نسخ قاعدة البيانات والمرفقات والنسخ الاحتياطية إلى المكان الجديد؟",
        flags=0x24,  # Yes/No + question
    )
    if ans != 6:  # IDYES
        return
    try:
        new_root.mkdir(parents=True, exist_ok=True)
        for child in old_root.iterdir():
            dest = new_root / child.name
            if child.is_dir():
                shutil.copytree(child, dest, dirs_exist_ok=True)
            else:
                shutil.copy2(child, dest)
    except Exception as e:
        win_message(f"تعذر نسخ البيانات السابقة بالكامل.\n\n{e}", flags=0x30)


def choose_data_root() -> Path:
    """Ask the user to choose the master data location on first run.

    The selection is remembered. Existing installations created by older builds have
    no ``locationConfirmed`` flag, so this build asks once instead of silently reusing
    the automatically selected LOCALAPPDATA folder.
    """
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    data = _read_config()
    old_raw = str(data.get("dataRoot") or "").strip()
    old_root = Path(old_raw).expanduser() if old_raw else None

    if data.get("locationConfirmed") is True and old_root:
        try:
            old_root = old_root.resolve()
            if old_root.exists() and is_fixed_windows_drive(old_root):
                return old_root
        except Exception:
            pass

    if os.name == "nt":
        while True:
            selected = browse_for_folder(
                "اختر مجلد حفظ قاعدة بيانات Sokhna Port والمرفقات والنسخ الاحتياطية"
            )
            if selected is None:
                win_message(
                    "لم يتم اختيار مكان حفظ البيانات.\n\n"
                    "افتح البرنامج مرة أخرى واختر مجلدًا على هارد داخلي ثابت.",
                    flags=0x30,
                )
                raise RuntimeError("لم يتم اختيار مكان حفظ بيانات البرنامج")
            if not is_fixed_windows_drive(selected):
                win_message(
                    "لا يمكن استخدام فلاشة USB أو قرص شبكي كقاعدة البيانات الرئيسية.\n\n"
                    "اختر مجلدًا على هارد داخلي ثابت مثل C: أو D:.",
                    flags=0x30,
                )
                continue
            root = selected
            break
    else:
        root = Path.home() / "CompanyInspectionData"

    root.mkdir(parents=True, exist_ok=True)
    _copy_existing_data_if_requested(old_root, root)
    data = _read_config()
    data.update({"dataRoot": str(root), "locationConfirmed": True})
    _write_config(data)
    return root


def windows_desktop_dir() -> Optional[Path]:
    if os.name != "nt":
        return None
    try:
        buf = ctypes.create_unicode_buffer(32768)
        # CSIDL_DESKTOPDIRECTORY = 0x0010
        hr = ctypes.windll.shell32.SHGetFolderPathW(None, 0x0010, None, 0, buf)
        if int(hr) == 0 and buf.value:
            return Path(buf.value)
    except Exception:
        pass
    for candidate in (
        Path(os.environ.get("OneDrive", "")) / "Desktop",
        Path.home() / "Desktop",
    ):
        if str(candidate) and candidate.exists():
            return candidate
    return None


def ensure_installed_exe_and_shortcut() -> Optional[Path]:
    """Keep one stable copy of the single EXE and create/update a desktop shortcut."""
    if os.name != "nt" or not getattr(sys, "frozen", False):
        return None
    try:
        source = Path(sys.executable).resolve()
        install_dir = Path(os.environ.get("LOCALAPPDATA") or str(Path.home())) / "Sokhna Port"
        install_dir.mkdir(parents=True, exist_ok=True)
        target = install_dir / "Sokhna Port.exe"
        if source != target:
            needs_copy = True
            if target.exists():
                try:
                    needs_copy = source.stat().st_size != target.stat().st_size
                    if not needs_copy:
                        def file_sha256(path: Path) -> str:
                            h = hashlib.sha256()
                            with open(path, "rb") as f:
                                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                                    h.update(chunk)
                            return h.hexdigest()
                        needs_copy = file_sha256(source) != file_sha256(target)
                except Exception:
                    needs_copy = True
            if needs_copy:
                shutil.copy2(source, target)
        else:
            target = source

        desktop = windows_desktop_dir()
        if not desktop:
            return target
        desktop.mkdir(parents=True, exist_ok=True)
        shortcut = desktop / "Sokhna Port.lnk"

        def ps_quote(v: str) -> str:
            return "'" + v.replace("'", "''") + "'"

        script = (
            "$ws=New-Object -ComObject WScript.Shell;"
            f"$s=$ws.CreateShortcut({ps_quote(str(shortcut))});"
            f"$s.TargetPath={ps_quote(str(target))};"
            f"$s.WorkingDirectory={ps_quote(str(target.parent))};"
            f"$s.IconLocation={ps_quote(str(target) + ',0')};"
            "$s.Description='Sokhna Port';"
            "$s.Save()"
        )
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=20,
            check=False,
            creationflags=creationflags,
        )
        return target
    except Exception:
        return None


def instance_info_path(root: Path) -> Path:
    return root / ".sokhna_port_instance.json"


def write_instance_info(root: Path, url: str, port: int) -> None:
    try:
        path = instance_info_path(root)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps({"app":"Sokhna Port","version":APP_VERSION,"pid":os.getpid(),"port":int(port),"url":str(url),"updatedAt":now_iso()}, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, path)
    except Exception:
        pass


def remove_instance_info(root: Path) -> None:
    try:
        path = instance_info_path(root)
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            if int(data.get("pid") or 0) == os.getpid():
                path.unlink(missing_ok=True)
    except Exception:
        pass


def read_running_instance_url(root: Path) -> Optional[str]:
    deadline = time.time() + 2.5
    path = instance_info_path(root)
    while time.time() < deadline:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            url = str(data.get("url") or "").strip()
            port = int(data.get("port") or 0)
            if url and port:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ping", timeout=0.7) as resp:
                    if int(getattr(resp, "status", 200)) == 200:
                        return url
        except Exception:
            pass
        time.sleep(0.18)
    return None


def bring_existing_window_to_front() -> bool:
    if os.name != "nt":
        return False
    try:
        user32 = ctypes.windll.user32
        found = {"hwnd": None}
        Proc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        def callback(hwnd, _):
            if not user32.IsWindowVisible(hwnd):
                return True
            n = int(user32.GetWindowTextLengthW(hwnd))
            if n <= 0:
                return True
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            if "Sokhna Port" in (buf.value or ""):
                found["hwnd"] = hwnd
                return False
            return True
        user32.EnumWindows(Proc(callback), 0)
        hwnd = found["hwnd"]
        if not hwnd:
            return False
        user32.ShowWindow(hwnd, 9)
        user32.SetForegroundWindow(hwnd)
        return True
    except Exception:
        return False


def focus_or_reopen_running_instance(root: Path) -> bool:
    if bring_existing_window_to_front():
        return True
    url = read_running_instance_url(root)
    if not url:
        return False
    if bring_existing_window_to_front():
        return True
    launch_app_window(url)
    return True


class FileLock:
    def __init__(self, path: Path):
        self.path = path
        self.fp = None

    def acquire(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.fp = open(self.path, "a+b")
        self.fp.seek(0)
        self.fp.write(b"0")
        self.fp.flush()
        self.fp.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.fp.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fp.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except Exception:
            try:
                self.fp.close()
            except Exception:
                pass
            self.fp = None
            raise RuntimeError("البرنامج مفتوح بالفعل على هذا المجلد. أغلق النسخة الأخرى ثم أعد المحاولة.")

    def release(self) -> None:
        if not self.fp:
            return
        try:
            self.fp.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.fp.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fp.fileno(), fcntl.LOCK_UN)
        except Exception:
            pass
        try:
            self.fp.close()
        except Exception:
            pass
        self.fp = None


class DesktopStore:
    def __init__(self, root: Path):
        self.paths = ensure_dirs(root)
        self.db_path = self.paths["database"] / "company_master.sqlite3"
        self.lock = threading.RLock()
        self.file_lock = FileLock(self.paths["database"] / ".company_master.lock")
        self.file_lock.acquire()
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False, timeout=20)
        self.conn.row_factory = sqlite3.Row
        self._post_write_lock = threading.Lock()
        self._post_write_timer: Optional[threading.Timer] = None
        self._closed = False
        self._last_excel_error = ""
        self._last_excel_update = ""
        self._init_db()
        self.schedule_post_write(1.2)

    def close(self) -> None:
        self._closed = True
        with self._post_write_lock:
            try:
                if self._post_write_timer:
                    self._post_write_timer.cancel()
            except Exception:
                pass
            self._post_write_timer = None
        with self.lock:
            try:
                self.conn.close()
            except Exception:
                pass
            self.file_lock.release()

    def _init_db(self) -> None:
        with self.lock:
            c = self.conn
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=FULL")
            c.execute("PRAGMA foreign_keys=ON")
            c.execute("PRAGMA busy_timeout=10000")
            c.executescript("""
                CREATE TABLE IF NOT EXISTS records(
                    store TEXT NOT NULL,
                    id TEXT NOT NULL,
                    data TEXT NOT NULL,
                    modified_at TEXT,
                    created_at TEXT,
                    is_deleted INTEGER NOT NULL DEFAULT 0,
                    company_id TEXT,
                    inspection_id TEXT,
                    entity_id TEXT,
                    PRIMARY KEY(store,id)
                );
                CREATE INDEX IF NOT EXISTS idx_records_store_deleted ON records(store,is_deleted);
                CREATE INDEX IF NOT EXISTS idx_records_company ON records(store,company_id);
                CREATE INDEX IF NOT EXISTS idx_records_inspection ON records(store,inspection_id);
                CREATE INDEX IF NOT EXISTS idx_records_entity ON records(store,entity_id);
                CREATE TABLE IF NOT EXISTS meta(
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
            """)
            c.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('desktopAppVersion',?)", (APP_VERSION,))
            c.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('schemaVersion',?)", (str(SCHEMA_VERSION),))
            c.commit()

    def excel_export_root(self) -> Path:
        cfg = _read_config()
        raw = str(cfg.get("excelExportRoot") or "").strip()
        candidate = Path(raw).expanduser() if raw else self.paths["excel_default"]
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            candidate = candidate.resolve()
            attachments = self.paths["attachments"].resolve()
            if candidate == attachments or attachments in candidate.parents:
                raise ValueError("Excel export folder cannot be inside Attachments")
            return candidate
        except Exception:
            fallback = self.paths["excel_default"]
            fallback.mkdir(parents=True, exist_ok=True)
            return fallback.resolve()

    def choose_excel_export_root(self) -> Tuple[Path, bool]:
        current = self.excel_export_root()
        selected = browse_for_folder("اختر مكان حفظ ملف Excel المباشر وحزم التصدير") if os.name == "nt" else None
        if selected is None:
            return current, True
        selected.mkdir(parents=True, exist_ok=True)
        selected = selected.resolve()
        attachments = self.paths["attachments"].resolve()
        if selected == attachments or attachments in selected.parents:
            raise ValueError("اختر مكان حفظ Excel خارج مجلد المرفقات Attachments")
        cfg = _read_config()
        cfg["excelExportRoot"] = str(selected)
        _write_config(cfg)
        try:
            self.refresh_live_excel_now()
        except Exception:
            pass
        return selected.resolve(), False

    @staticmethod
    def _tree_stats(folder: Path) -> Tuple[int, int]:
        count = 0
        total = 0
        if not folder.exists():
            return 0, 0
        for p in folder.rglob("*"):
            try:
                if p.is_file():
                    count += 1
                    total += p.stat().st_size
            except Exception:
                pass
        return count, total

    def move_data_root(self, new_root: Path) -> Dict[str, Any]:
        """Safely switch the live master DB + attachments to another fixed internal drive.

        The old root is intentionally kept as a safety copy. The move is implemented as
        copy -> integrity verification -> config switch -> live connection switch.
        """
        old_root = self.paths["root"].resolve()
        new_root = Path(new_root).expanduser().resolve()
        if new_root == old_root:
            return {"cancelled": True, "same": True, "oldRoot": str(old_root), "newRoot": str(new_root)}
        if os.name == "nt" and not is_fixed_windows_drive(new_root):
            raise ValueError("اختر مجلدًا على هارد داخلي ثابت مثل C: أو D:. لا يمكن نقل القاعدة إلى فلاشة أو قرص شبكي.")
        if old_root in new_root.parents or new_root in old_root.parents:
            raise ValueError("اختر مجلدًا مستقلاً خارج مجلد البيانات الحالي.")

        new_root.mkdir(parents=True, exist_ok=True)
        new_paths = ensure_dirs(new_root)
        new_db = new_paths["database"] / "company_master.sqlite3"
        if new_db.exists() and new_db.stat().st_size > 0:
            raise ValueError("المجلد المختار يحتوي بالفعل على قاعدة بيانات Sokhna Port. اختر مجلدًا فارغًا أو مكانًا جديدًا.")
        if any(p.is_file() for p in new_paths["attachments"].rglob("*")):
            raise ValueError("المجلد المختار يحتوي مرفقات سابقة. اختر مجلدًا فارغًا حتى لا تختلط البيانات.")

        # Create a verified operational backup before touching anything.
        safety_backup = self.create_backup("MANUAL")

        # Prevent background Excel/attachment maintenance during the transfer.
        with self._post_write_lock:
            try:
                if self._post_write_timer:
                    self._post_write_timer.cancel()
            except Exception:
                pass
            self._post_write_timer = None

        old_conn = self.conn
        old_lock = self.file_lock
        new_lock: Optional[FileLock] = None
        new_conn: Optional[sqlite3.Connection] = None
        tmp_db = new_paths["database"] / f".moving_{stamp()}.sqlite3"
        try:
            with self.lock:
                try:
                    old_conn.execute("PRAGMA wal_checkpoint(FULL)")
                except Exception:
                    pass
                dst = sqlite3.connect(str(tmp_db), timeout=20)
                try:
                    old_conn.backup(dst)
                    chk = dst.execute("PRAGMA integrity_check").fetchone()
                    if not chk or str(chk[0]).lower() != "ok":
                        raise RuntimeError("فشل فحص سلامة نسخة قاعدة البيانات الجديدة")
                    dst.commit()
                finally:
                    dst.close()
                os.replace(tmp_db, new_db)

                # Copy all user-visible data folders. Keep the old root untouched as safety copy.
                for key in ("attachments", "daily", "weekly", "manual", "recovery_weekly", "recovery_manual", "excel_default", "logs"):
                    src = self.paths[key]
                    dst_dir = new_paths[key]
                    if src.exists():
                        shutil.copytree(src, dst_dir, dirs_exist_ok=True)

                old_att_stats = self._tree_stats(self.paths["attachments"])
                new_att_stats = self._tree_stats(new_paths["attachments"])
                if old_att_stats != new_att_stats:
                    raise RuntimeError(f"تعذر التحقق من نسخ المرفقات بالكامل: القديم {old_att_stats} والجديد {new_att_stats}")

                new_lock = FileLock(new_paths["database"] / ".company_master.lock")
                new_lock.acquire()
                new_conn = sqlite3.connect(str(new_db), check_same_thread=False, timeout=20)
                new_conn.row_factory = sqlite3.Row
                new_conn.execute("PRAGMA journal_mode=WAL")
                new_conn.execute("PRAGMA synchronous=FULL")
                new_conn.execute("PRAGMA foreign_keys=ON")
                new_conn.execute("PRAGMA busy_timeout=10000")
                chk = new_conn.execute("PRAGMA quick_check").fetchone()
                if not chk or str(chk[0]).lower() != "ok":
                    raise RuntimeError("فشل فحص SQLite في المكان الجديد")

                cfg = _read_config()
                old_excel_raw = str(cfg.get("excelExportRoot") or "").strip()
                if old_excel_raw:
                    try:
                        old_excel = Path(old_excel_raw).expanduser().resolve()
                        if old_excel == old_root or old_root in old_excel.parents:
                            rel = old_excel.relative_to(old_root)
                            cfg["excelExportRoot"] = str((new_root / rel).resolve())
                    except Exception:
                        pass
                cfg.update({"dataRoot": str(new_root), "locationConfirmed": True})
                _write_config(cfg)

                # Switch the live store only after every verification has succeeded.
                self.paths = new_paths
                self.db_path = new_db
                self.file_lock = new_lock
                self.conn = new_conn
                self._closed = False
                new_lock = None
                new_conn = None
                self._init_db()

                try:
                    old_conn.close()
                finally:
                    old_lock.release()

                # Move the running-instance marker too, so reopening the shortcut focuses this process.
                try:
                    old_marker = instance_info_path(old_root)
                    new_marker = instance_info_path(new_root)
                    if old_marker.exists():
                        shutil.copy2(old_marker, new_marker)
                        old_marker.unlink(missing_ok=True)
                except Exception:
                    pass

                try:
                    (old_root / "DATA_MOVED_TO.txt").write_text(
                        f"Sokhna Port data moved safely to:\n{new_root}\n\nMoved at: {now_iso()}\n"
                        "The old folder was kept as a safety copy and can be removed manually only after checking the new location.",
                        encoding="utf-8",
                    )
                except Exception:
                    pass
        except Exception:
            try:
                if new_conn is not None:
                    new_conn.close()
            except Exception:
                pass
            try:
                if new_lock is not None:
                    new_lock.release()
            except Exception:
                pass
            try:
                tmp_db.unlink(missing_ok=True)
            except Exception:
                pass
            self.schedule_post_write(0.8)
            raise

        self.schedule_post_write(0.2)
        return {
            "cancelled": False,
            "oldRoot": str(old_root),
            "newRoot": str(new_root),
            "database": str(self.db_path),
            "attachments": str(self.paths["attachments"]),
            "safetyCopyKept": True,
            "preMoveBackup": str(safety_backup),
        }

    def choose_and_move_data_root(self) -> Dict[str, Any]:
        if os.name != "nt":
            return {"cancelled": True, "reason": "folder-picker-windows-only", "newRoot": str(self.paths["root"])}
        selected = browse_for_folder("اختر المكان الجديد لقاعدة بيانات Sokhna Port والمرفقات")
        if selected is None:
            return {"cancelled": True, "newRoot": str(self.paths["root"])}
        return self.move_data_root(selected)

    def set_excel_settings(self, yellow_days: Any = 60, red_days: Any = 0) -> None:
        try:
            yellow = max(0, int(float(yellow_days)))
        except Exception:
            yellow = 60
        try:
            red = max(0, int(float(red_days)))
        except Exception:
            red = 0
        cfg = _read_config()
        cfg["excelSettings"] = {"yellowDays": yellow, "redDays": red}
        _write_config(cfg)
        self.schedule_post_write(0.2)

    def excel_settings(self) -> Dict[str, int]:
        cfg = _read_config()
        x = cfg.get("excelSettings") if isinstance(cfg.get("excelSettings"), dict) else {}
        try:
            yellow = max(0, int(float(x.get("yellowDays", 60))))
        except Exception:
            yellow = 60
        try:
            red = max(0, int(float(x.get("redDays", 0))))
        except Exception:
            red = 0
        return {"yellowDays": yellow, "redDays": red}

    def schedule_post_write(self, delay: float = 0.65) -> None:
        if self._closed:
            return
        with self._post_write_lock:
            try:
                if self._post_write_timer:
                    self._post_write_timer.cancel()
            except Exception:
                pass
            timer = threading.Timer(max(0.05, float(delay)), self._post_write_worker)
            timer.daemon = True
            self._post_write_timer = timer
            timer.start()

    def _post_write_worker(self) -> None:
        if self._closed:
            return
        try:
            self.organize_existing_attachments()
        except Exception as e:
            self._log_maintenance_error("attachments", e)
        try:
            self.refresh_live_excel_now()
        except Exception as e:
            self._last_excel_error = str(e)
            self._log_maintenance_error("excel", e)
        finally:
            with self._post_write_lock:
                self._post_write_timer = None

    def _log_maintenance_error(self, area: str, exc: Exception) -> None:
        try:
            log = self.paths["logs"] / "maintenance.log"
            with open(log, "a", encoding="utf-8") as f:
                f.write(f"{dt.datetime.now().isoformat(timespec='seconds')} {area}: {exc}\n")
        except Exception:
            pass

    def _record_row(self, store: str, rec: Dict[str, Any]) -> Tuple[Any, ...]:
        return (
            store,
            str(rec.get("id", "")),
            json_dumps(rec),
            str(rec.get("modifiedAt", "") or ""),
            str(rec.get("createdAt", "") or ""),
            1 if rec.get("isDeleted") else 0,
            str(rec.get("companyId", "") or ""),
            str(rec.get("inspectionId", "") or ""),
            str(rec.get("entityId", "") or ""),
        )

    def _upsert(self, cur: sqlite3.Cursor, store: str, rec: Dict[str, Any]) -> None:
        if store not in STORES:
            raise ValueError(f"مخزن غير معروف: {store}")
        if not isinstance(rec, dict) or not rec.get("id"):
            raise ValueError(f"سجل غير صالح في {store}")
        rec = self._externalize_record(store, copy.deepcopy(rec), cur)
        cur.execute(
            """INSERT INTO records(store,id,data,modified_at,created_at,is_deleted,company_id,inspection_id,entity_id)
               VALUES(?,?,?,?,?,?,?,?,?)
               ON CONFLICT(store,id) DO UPDATE SET
                 data=excluded.data, modified_at=excluded.modified_at, created_at=excluded.created_at,
                 is_deleted=excluded.is_deleted, company_id=excluded.company_id,
                 inspection_id=excluded.inspection_id, entity_id=excluded.entity_id""",
            self._record_row(store, rec),
        )

    @staticmethod
    def _parse_data_url(data_url: str) -> Tuple[str, bytes]:
        if not isinstance(data_url, str) or not data_url.startswith("data:"):
            raise ValueError("بيانات الملف ليست Data URL")
        head, sep, body = data_url.partition(",")
        if not sep:
            raise ValueError("Data URL غير صالح")
        mime = head[5:].split(";", 1)[0] or "application/octet-stream"
        if ";base64" in head:
            raw = base64.b64decode(body, validate=False)
        else:
            raw = urllib.parse.unquote_to_bytes(body)
        return mime, raw

    def _write_bytes(self, rel: str, raw: bytes) -> Tuple[str, int]:
        rel = rel.replace("\\", "/").lstrip("/")
        target = (self.paths["root"] / rel).resolve()
        root = self.paths["root"].resolve()
        if root not in target.parents and target != root:
            raise ValueError("مسار مرفق غير مسموح")
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.with_name(target.name + ".tmp")
        with open(tmp, "wb") as f:
            f.write(raw)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, target)
        return hashlib.sha256(raw).hexdigest(), len(raw)

    def _get_existing_raw(self, cur: sqlite3.Cursor, store: str, rec_id: str) -> Optional[Dict[str, Any]]:
        row = cur.execute("SELECT data FROM records WHERE store=? AND id=?", (store, rec_id)).fetchone()
        if not row:
            return None
        try:
            return json.loads(row[0])
        except Exception:
            return None

    def _company_for_record(self, cur: sqlite3.Cursor, entity_type: str, entity_id: str) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]], str]:
        et = str(entity_type or "").lower()
        eid = str(entity_id or "")
        record: Optional[Dict[str, Any]] = None
        company: Optional[Dict[str, Any]] = None
        label = "مرفقات"
        if et == "company":
            company = self._get_existing_raw(cur, "companies", eid)
            record = company
            label = "مرفقات الشركة"
        elif et == "item":
            record = self._get_existing_raw(cur, "items", eid)
            if record:
                company = self._get_existing_raw(cur, "companies", str(record.get("companyId") or ""))
                label = str(record.get("name") or "بند")
        elif et == "inspection":
            record = self._get_existing_raw(cur, "inspections", eid)
            if record:
                company = self._get_existing_raw(cur, "companies", str(record.get("companyId") or ""))
                code = record.get("inspectionCode") or record.get("inspectionNo") or record.get("date") or "تفتيش"
                label = f"تفتيش - {code}"
        elif et in ("finding", "ncr"):
            store = "findings" if et == "finding" else "ncrs"
            record = self._get_existing_raw(cur, store, eid)
            if record:
                inspection = self._get_existing_raw(cur, "inspections", str(record.get("inspectionId") or ""))
                if inspection:
                    company = self._get_existing_raw(cur, "companies", str(inspection.get("companyId") or ""))
                    code = inspection.get("inspectionCode") or inspection.get("inspectionNo") or inspection.get("date") or "تفتيش"
                else:
                    code = "تفتيش"
                no = str(record.get("no") or "").strip()
                req = str(record.get("requirement") or record.get("description") or "").strip()
                req = safe_part(req, "ملاحظة")[:55]
                label = f"NCR {no or safe_part(eid)[:8]} - {code} - {req}"
        return company, record, label

    def _friendly_attachment_rel(self, cur: sqlite3.Cursor, entity_type: str, entity_id: str, filename: str, attachment_id: str, current_rel: str = "") -> str:
        company, _, record_label = self._company_for_record(cur, entity_type, entity_id)
        company_name = safe_part((company or {}).get("name") or f"شركة_{safe_part((company or {}).get('id') or entity_id)[:20]}", "شركة")[:80]
        folder_name = safe_part(record_label, "مرفقات")[:90]
        raw_name = safe_part(filename or attachment_id or "مرفق", "مرفق")
        pp0 = Path(raw_name); ext0 = pp0.suffix[:15]; stem0 = safe_part(pp0.stem, "مرفق")[:85]
        name = stem0 + ext0
        rel = f"Attachments/{company_name}/{folder_name}/{name}"
        target = self.paths["root"] / rel
        if target.exists() and current_rel.replace("\\", "/") != rel:
            pp = Path(name)
            suffix = safe_part(attachment_id, "id")[:8]
            name = f"{safe_part(pp.stem, 'مرفق')} ({suffix}){pp.suffix}"
            rel = f"Attachments/{company_name}/{folder_name}/{name}"
        return rel

    def _friendly_finding_photo_rel(self, cur: sqlite3.Cursor, rec: Dict[str, Any], role: str, ext: str) -> str:
        inspection = self._get_existing_raw(cur, "inspections", str(rec.get("inspectionId") or "")) or {}
        company = self._get_existing_raw(cur, "companies", str(inspection.get("companyId") or "")) or {}
        code = inspection.get("inspectionCode") or inspection.get("inspectionNo") or inspection.get("date") or "تفتيش"
        no = str(rec.get("no") or "").strip() or safe_part(rec.get("id") or "NCR")[:8]
        req = safe_part(rec.get("requirement") or rec.get("description") or "ملاحظة", "ملاحظة")[:55]
        record_label = f"NCR {no} - {code} - {req}"
        company_name = safe_part(company.get("name") or "شركة", "شركة")[:80]
        folder_name = safe_part(record_label, "NCR")[:90]
        arabic_role = "صورة قبل" if role == "before" else "صورة بعد"
        return f"Attachments/{company_name}/{folder_name}/{arabic_role}{ext}"

    def organize_existing_attachments(self) -> int:
        moved = 0
        remove_after: List[Path] = []
        with self.lock:
            cur = self.conn.cursor()
            try:
                cur.execute("BEGIN IMMEDIATE")
                rows = cur.execute("SELECT id,data FROM records WHERE store='attachments'").fetchall()
                for row in rows:
                    try:
                        rec = json.loads(row["data"])
                    except Exception:
                        continue
                    if rec.get("isDeleted") or not rec.get("relativePath"):
                        continue
                    old_rel = str(rec.get("relativePath") or "").replace("\\", "/")
                    desired = self._friendly_attachment_rel(cur, str(rec.get("entityType") or "other"), str(rec.get("entityId") or ""), str(rec.get("filename") or rec.get("id") or "مرفق"), str(rec.get("id") or "id"), old_rel)
                    if old_rel == desired:
                        continue
                    src = self.paths["root"] / old_rel
                    dst = self.paths["root"] / desired
                    if not src.is_file() and not dst.is_file():
                        continue
                    if src.is_file():
                        raw = src.read_bytes()
                        sha, size = self._write_bytes(desired, raw)
                    else:
                        raw = dst.read_bytes()
                        sha, size = hashlib.sha256(raw).hexdigest(), len(raw)
                    rec["relativePath"] = desired
                    rec["externalPath"] = desired.replace("Attachments/", "", 1)
                    rec["externalAttachment"] = True
                    rec["sha256"] = sha
                    rec["size"] = int(size)
                    cur.execute("UPDATE records SET data=? WHERE store='attachments' AND id=?", (json_dumps(rec), str(rec.get("id") or row["id"])))
                    if src.is_file() and src.resolve() != dst.resolve():
                        remove_after.append(src)
                    moved += 1
                frows = cur.execute("SELECT id,data FROM records WHERE store='findings'").fetchall()
                for row in frows:
                    try:
                        rec = json.loads(row["data"])
                    except Exception:
                        continue
                    if rec.get("isDeleted"):
                        continue
                    changed = False
                    for role in ("before", "after"):
                        pf = f"_{role}PhotoPath"
                        old_rel = str(rec.get(pf) or "").replace("\\", "/")
                        if not old_rel:
                            continue
                        ext = Path(old_rel).suffix or mimetypes.guess_extension(str(rec.get(f"_{role}PhotoMime") or "image/jpeg")) or ".jpg"
                        desired = self._friendly_finding_photo_rel(cur, rec, role, ext)
                        if desired == old_rel:
                            continue
                        src = self.paths["root"] / old_rel
                        dst = self.paths["root"] / desired
                        if not src.is_file() and not dst.is_file():
                            continue
                        if src.is_file():
                            raw = src.read_bytes()
                            sha, size = self._write_bytes(desired, raw)
                        else:
                            raw = dst.read_bytes()
                            sha, size = hashlib.sha256(raw).hexdigest(), len(raw)
                        rec[pf] = desired
                        rec[f"_{role}PhotoSha256"] = sha
                        rec[f"_{role}PhotoSize"] = int(size)
                        rec[f"{role}PhotoExternal"] = True
                        if src.is_file() and src.resolve() != dst.resolve():
                            remove_after.append(src)
                        changed = True
                        moved += 1
                    if changed:
                        cur.execute("UPDATE records SET data=? WHERE store='findings' AND id=?", (json_dumps(rec), str(rec.get("id") or row["id"])))
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise
        for old in remove_after:
            try:
                old.unlink(missing_ok=True)
                parent = old.parent
                root = self.paths["attachments"].resolve()
                while parent != root and root in parent.resolve().parents and parent.exists() and not any(parent.iterdir()):
                    parent.rmdir()
                    parent = parent.parent
            except Exception:
                pass
        return moved

    def _externalize_attachment(self, rec: Dict[str, Any], cur: sqlite3.Cursor) -> Dict[str, Any]:
        existing = self._get_existing_raw(cur, "attachments", str(rec.get("id"))) or {}
        data = rec.get("dataUrl", "")
        if isinstance(data, str) and data.startswith("data:"):
            mime, raw = self._parse_data_url(data)
            ext = Path(str(rec.get("filename") or "")).suffix.lower()
            if not ext:
                ext = mimetypes.guess_extension(mime) or ".bin"
            filename = str(rec.get("filename") or (safe_part(rec.get("id")) + ext))
            if not Path(filename).suffix:
                filename += ext
            rel = self._friendly_attachment_rel(cur, str(rec.get("entityType") or "other"), str(rec.get("entityId") or ""), filename, str(rec.get("id") or "id"), str(existing.get("relativePath") or ""))
            sha, size = self._write_bytes(rel, raw)
            rec["relativePath"] = rel
            rec["externalPath"] = rel.replace("Attachments/", "", 1)
            rec["externalAttachment"] = True
            rec["sha256"] = sha
            rec["size"] = int(size)
            rec["mime"] = rec.get("mime") or mime
            rec["dataUrl"] = ""
        elif isinstance(data, str) and data.startswith("/api/file"):
            rec["dataUrl"] = ""
            for k in ("relativePath", "externalPath", "externalAttachment", "sha256", "size", "mime"):
                if not rec.get(k) and existing.get(k) not in (None, ""):
                    rec[k] = existing.get(k)
        elif not data:
            # A normal fetched record has dataUrl='' in SQLite. Keep its physical metadata.
            for k in ("relativePath", "externalPath", "externalAttachment", "sha256", "size", "mime"):
                if not rec.get(k) and existing.get(k) not in (None, ""):
                    rec[k] = existing.get(k)
            rec["dataUrl"] = ""
        else:
            # Unknown URL should never be persisted as the master file source.
            rec["dataUrl"] = ""
        return rec

    def _externalize_finding_photo(self, rec: Dict[str, Any], role: str, existing: Dict[str, Any], cur: sqlite3.Cursor) -> None:
        field = f"{role}PhotoData"
        path_field = f"_{role}PhotoPath"
        sha_field = f"_{role}PhotoSha256"
        mime_field = f"_{role}PhotoMime"
        size_field = f"_{role}PhotoSize"
        marker_field = f"{role}PhotoExternal"
        value = rec.get(field, None)
        if isinstance(value, str) and value.startswith("data:"):
            mime, raw = self._parse_data_url(value)
            ext = mimetypes.guess_extension(mime) or ".jpg"
            if ext == ".jpe":
                ext = ".jpg"
            rel = self._friendly_finding_photo_rel(cur, rec, role, ext)
            sha, size = self._write_bytes(rel, raw)
            rec[path_field] = rel
            rec[sha_field] = sha
            rec[mime_field] = mime
            rec[size_field] = int(size)
            rec[marker_field] = True
            rec[field] = ""
        elif isinstance(value, str) and value.startswith("/api/file"):
            rec[field] = ""
            for k in (path_field, sha_field, mime_field, size_field, marker_field):
                if rec.get(k) in (None, "") and existing.get(k) not in (None, ""):
                    rec[k] = existing.get(k)
        elif value == "":
            # Data-only sync records deliberately have no embedded photo but DO carry path/hash metadata.
            # Preserve that linkage. A UI deletion clears the path metadata too (patched in desktop HTML).
            if rec.get(path_field):
                rec[field] = ""
                rec[marker_field] = bool(rec.get(marker_field, True))
            else:
                # Logical deletion: unlink it from the record. The old physical file stays on disk for recovery safety.
                rec[field] = ""
                rec[path_field] = ""
                rec[sha_field] = ""
                rec[size_field] = 0
                rec[marker_field] = False
        elif value is None:
            # Field omitted: preserve existing linkage.
            rec[field] = ""
            for k in (path_field, sha_field, mime_field, size_field, marker_field):
                if k not in rec and k in existing:
                    rec[k] = existing[k]
        else:
            rec[field] = ""

    def _externalize_record(self, store: str, rec: Dict[str, Any], cur: sqlite3.Cursor) -> Dict[str, Any]:
        if store == "attachments":
            return self._externalize_attachment(rec, cur)
        if store == "findings":
            existing = self._get_existing_raw(cur, "findings", str(rec.get("id"))) or {}
            self._externalize_finding_photo(rec, "before", existing, cur)
            self._externalize_finding_photo(rec, "after", existing, cur)
        return rec

    def put(self, store: str, rec: Dict[str, Any]) -> None:
        with self.lock:
            cur = self.conn.cursor()
            try:
                cur.execute("BEGIN IMMEDIATE")
                self._upsert(cur, store, rec)
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise
        self.schedule_post_write()

    def put_many(self, store: str, rows: Iterable[Dict[str, Any]]) -> None:
        with self.lock:
            cur = self.conn.cursor()
            try:
                cur.execute("BEGIN IMMEDIATE")
                for rec in rows:
                    self._upsert(cur, store, rec)
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise
        self.schedule_post_write()

    def atomic_batches(self, batches: Dict[str, List[Dict[str, Any]]]) -> None:
        with self.lock:
            cur = self.conn.cursor()
            try:
                cur.execute("BEGIN IMMEDIATE")
                for store, rows in batches.items():
                    for rec in rows or []:
                        self._upsert(cur, store, rec)
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise
        self.schedule_post_write()

    def clear(self, store: str) -> None:
        if store not in STORES:
            raise ValueError("مخزن غير معروف")
        with self.lock:
            self.conn.execute("DELETE FROM records WHERE store=?", (store,))
            self.conn.commit()
        self.schedule_post_write()

    def delete_one(self, store: str, rec_id: str) -> None:
        if store not in STORES:
            raise ValueError("مخزن غير معروف")
        with self.lock:
            self.conn.execute("DELETE FROM records WHERE store=? AND id=?", (store, rec_id))
            self.conn.commit()
        self.schedule_post_write()

    def delete_many_atomic(self, batches: Dict[str, List[str]]) -> None:
        if not isinstance(batches, dict):
            raise ValueError("طلب الحذف غير صالح")
        clean: Dict[str, List[str]] = {}
        for store, ids in batches.items():
            if store not in STORES:
                raise ValueError(f"مخزن غير معروف: {store}")
            if not isinstance(ids, list):
                raise ValueError(f"قائمة الحذف غير صالحة في {store}")
            vals = [str(x) for x in ids if str(x or "").strip()]
            if vals:
                clean[store] = vals
        if not clean:
            return
        with self.lock:
            cur = self.conn.cursor()
            try:
                cur.execute("BEGIN IMMEDIATE")
                for store, ids in clean.items():
                    cur.executemany("DELETE FROM records WHERE store=? AND id=?", [(store, rec_id) for rec_id in ids])
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise
        self.schedule_post_write(0.2)

    def raw_one(self, store: str, rec_id: str) -> Optional[Dict[str, Any]]:
        if store not in STORES:
            raise ValueError("مخزن غير معروف")
        with self.lock:
            row = self.conn.execute("SELECT data FROM records WHERE store=? AND id=?", (store, rec_id)).fetchone()
        if not row:
            return None
        return json.loads(row[0])

    def raw_all(self, store: str) -> List[Dict[str, Any]]:
        if store not in STORES:
            raise ValueError("مخزن غير معروف")
        with self.lock:
            rows = self.conn.execute("SELECT data FROM records WHERE store=? ORDER BY rowid", (store,)).fetchall()
        return [json.loads(r[0]) for r in rows]

    def all_data(self) -> Dict[str, List[Dict[str, Any]]]:
        return {s: self.raw_all(s) for s in STORES}

    @staticmethod
    def _file_url(rel: str) -> str:
        return "/api/file?path=" + urllib.parse.quote(rel.replace("\\", "/"), safe="")

    def client_record(self, store: str, rec: Dict[str, Any]) -> Dict[str, Any]:
        out = copy.deepcopy(rec)
        if store == "attachments" and not out.get("isDeleted") and out.get("relativePath"):
            p = self.paths["root"] / str(out.get("relativePath"))
            if p.exists():
                out["dataUrl"] = self._file_url(str(out.get("relativePath")))
        if store == "findings" and not out.get("isDeleted"):
            for role in ("before", "after"):
                pf = f"_{role}PhotoPath"
                df = f"{role}PhotoData"
                rel = out.get(pf)
                if rel and (self.paths["root"] / str(rel)).exists():
                    out[df] = self._file_url(str(rel))
        return out

    def get_one(self, store: str, rec_id: str) -> Optional[Dict[str, Any]]:
        r = self.raw_one(store, rec_id)
        return self.client_record(store, r) if r else None

    def get_all(self, store: str) -> List[Dict[str, Any]]:
        return [self.client_record(store, r) for r in self.raw_all(store)]

    def replace_all(self, data: Dict[str, List[Dict[str, Any]]]) -> None:
        for store in STORES:
            rows = data.get(store, [])
            if not isinstance(rows, list):
                raise ValueError(f"بيانات {store} غير صالحة")
            for rec in rows:
                if not isinstance(rec, dict) or not rec.get("id"):
                    raise ValueError(f"يوجد سجل غير صالح في {store}")
        # Mandatory safety copy immediately before destructive full replacement.
        self.create_backup("PRE_RESTORE")
        with self.lock:
            cur = self.conn.cursor()
            try:
                cur.execute("BEGIN IMMEDIATE")
                cur.execute("DELETE FROM records")
                for store in STORES:
                    for rec in data.get(store, []):
                        self._upsert(cur, store, rec)
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise
        self.schedule_post_write(0.2)

    def _rel_file_bytes(self, rel: str) -> Optional[bytes]:
        if not rel:
            return None
        p = (self.paths["root"] / rel).resolve()
        root = self.paths["root"].resolve()
        if root not in p.parents or not p.is_file():
            return None
        return p.read_bytes()

    @staticmethod
    def _data_url(mime: str, raw: bytes) -> str:
        return f"data:{mime or 'application/octet-stream'};base64," + base64.b64encode(raw).decode("ascii")

    def export_data(self, include_files: bool, since: Optional[str] = None) -> Dict[str, List[Dict[str, Any]]]:
        data: Dict[str, List[Dict[str, Any]]] = {}
        for store in STORES:
            rows = self.raw_all(store)
            if since:
                rows = [r for r in rows if str(r.get("modifiedAt") or r.get("createdAt") or "") > since]
            out_rows = []
            for rec0 in rows:
                rec = copy.deepcopy(rec0)
                if store == "attachments":
                    rec["dataUrl"] = ""
                    if include_files and not rec.get("isDeleted") and rec.get("relativePath"):
                        raw = self._rel_file_bytes(str(rec.get("relativePath")))
                        if raw is not None:
                            rec["dataUrl"] = self._data_url(str(rec.get("mime") or "application/octet-stream"), raw)
                elif store == "findings":
                    for role in ("before", "after"):
                        df = f"{role}PhotoData"
                        pf = f"_{role}PhotoPath"
                        mf = f"_{role}PhotoMime"
                        rec[df] = ""
                        if include_files and not rec.get("isDeleted") and rec.get(pf):
                            raw = self._rel_file_bytes(str(rec.get(pf)))
                            if raw is not None:
                                rec[df] = self._data_url(str(rec.get(mf) or "image/jpeg"), raw)
                out_rows.append(rec)
            data[store] = out_rows
        return data

    def export_payload(self, kind: str, include_files: bool, since: Optional[str], source_device_id: str, source_device_name: str) -> Dict[str, Any]:
        generated = now_iso()
        data = self.export_data(include_files=include_files, since=since)
        payload = {
            "schema": "company-mobile-sync",
            "schemaVersion": SCHEMA_VERSION,
            "kind": kind,
            "exportId": hashlib.sha256((generated + source_device_id + kind).encode()).hexdigest()[:32],
            "sourceRole": "computer-master",
            "sourceDeviceId": source_device_id or "computer-master",
            "sourceDeviceName": source_device_name or "الكمبيوتر الرئيسي",
            "generatedAt": generated,
            "since": since or "1970-01-01T00:00:00.000Z",
            "appVersion": APP_VERSION,
            "attachmentMode": "embedded" if include_files else "index-only",
            "data": data,
            "counts": {s: len(data.get(s, [])) for s in STORES},
            "companySerialHighWater": max([int(c.get("companySerial") or 0) for c in data.get("companies", [])] + [0]),
        }
        return payload

    def _sqlite_snapshot(self, out_db: Path) -> None:
        out_db.parent.mkdir(parents=True, exist_ok=True)
        if out_db.exists():
            out_db.unlink()
        with self.lock:
            dst = sqlite3.connect(str(out_db))
            try:
                self.conn.backup(dst)
            finally:
                dst.close()

    def create_backup(self, category: str = "Manual") -> Path:
        cat = category.upper()
        if cat == "DAILY":
            dest_dir = self.paths["daily"]
            prefix = "DAILY"
        elif cat == "WEEKLY":
            dest_dir = self.paths["weekly"]
            prefix = "WEEKLY"
        else:
            dest_dir = self.paths["manual"]
            prefix = safe_part(category.upper(), "MANUAL")
        dest_dir.mkdir(parents=True, exist_ok=True)
        out = dest_dir / f"{prefix}_BACKUP_{stamp()}.zip"
        tmp_db = self.paths["database"] / f".backup_{stamp()}.sqlite3"
        self._sqlite_snapshot(tmp_db)
        try:
            with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as z:
                z.write(tmp_db, arcname="Database/company_master.sqlite3")
                att_root = self.paths["attachments"]
                for p in att_root.rglob("*"):
                    if p.is_file():
                        z.write(p, arcname=str(p.relative_to(self.paths["root"])).replace("\\", "/"))
                manifest = {
                    "type": "Company Inspection Desktop Backup",
                    "version": APP_VERSION,
                    "createdAt": now_iso(),
                    "category": category,
                    "dataRoot": str(self.paths["root"]),
                }
                z.writestr("BACKUP_INFO.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        finally:
            try:
                tmp_db.unlink()
            except Exception:
                pass
        return out

    def _xlsx_xml_escape(self, value: Any) -> str:
        return html.escape(str(value if value is not None else ""), quote=False)

    @staticmethod
    def _display_date(value: Any) -> str:
        raw = str(value or "").strip()
        m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", raw)
        if m:
            return f"{m.group(3)}/{m.group(2)}/{m.group(1)}"
        return raw

    @staticmethod
    def _excel_item_state(item: Dict[str, Any], yellow_days: int = 60, red_days: int = 0) -> str:
        if item.get("noExpiry") or not item.get("expiryDate"):
            return "بدون تاريخ انتهاء"
        try:
            exp = dt.date.fromisoformat(str(item.get("expiryDate"))[:10])
            today = dt.date.today()
            if exp <= today + dt.timedelta(days=red_days):
                return "منتهية"
            if exp <= today + dt.timedelta(days=yellow_days):
                return "قريبة الانتهاء"
            return "سارية"
        except Exception:
            return "غير محدد"

    @staticmethod
    def _excel_status_ar(value: Any) -> str:
        v = str(value or "")
        return {"Open":"مفتوح", "Partial":"جزئي", "Closed":"مغلق"}.get(v, v)

    def _company_maps(self, data: Dict[str, List[Dict[str, Any]]]) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, Dict[str, Any]], Dict[str, Dict[str, Any]]]:
        companies = {str(x.get("id")): x for x in data.get("companies", []) if x.get("id")}
        items = {str(x.get("id")): x for x in data.get("items", []) if x.get("id")}
        inspections = {str(x.get("id")): x for x in data.get("inspections", []) if x.get("id")}
        return companies, items, inspections

    def _company_profile_value(self, company: Dict[str, Any], field: Dict[str, Any], item_map: Dict[str, Dict[str, Any]]) -> str:
        linked_id = str(field.get("linkedItemId") or "")
        item = item_map.get(linked_id) if linked_id else None
        prop = str(field.get("linkedProperty") or "currentStatus")
        if item:
            if prop == "name": return str(item.get("name") or "")
            if prop == "issueDate": return self._display_date(item.get("issueDate"))
            if prop == "expiryDate": return "بدون تاريخ انتهاء" if item.get("noExpiry") else self._display_date(item.get("expiryDate"))
            if prop == "validity": return self._excel_item_state(item, **self._excel_state_kwargs())
            if prop == "summary":
                bits = [str(item.get("currentStatus") or "").strip(), self._excel_item_state(item, **self._excel_state_kwargs())]
                if item.get("expiryDate") and not item.get("noExpiry"):
                    bits.append("ينتهي " + self._display_date(item.get("expiryDate")))
                return " — ".join(x for x in bits if x)
            return str(item.get("currentStatus") or "")
        val = field.get("value", "")
        if isinstance(val, dict):
            return " - ".join(str(val.get(k) or "") for k in ("name", "phone") if val.get(k))
        if isinstance(val, (list, dict)):
            return json.dumps(val, ensure_ascii=False)
        if str(field.get("type") or "") == "date":
            return self._display_date(val)
        return str(val if val is not None else "")

    def _excel_state_kwargs(self) -> Dict[str, int]:
        st = self.excel_settings()
        return {"yellow_days": int(st.get("yellowDays", 60)), "red_days": int(st.get("redDays", 0))}

    def _program_excel_sheets(self, relative_links: bool = False) -> List[Dict[str, Any]]:
        """Build a human-readable Excel mirror of the desktop program.

        Visible worksheets follow the same main screens and Arabic labels used by the UI.
        A hidden recovery sheet preserves every record as JSON for lossless audit/recovery use.
        """
        data = self.all_data()
        active = lambda rows: [x for x in rows if not x.get("isDeleted")]
        companies = active(data.get("companies", []))
        items = [x for x in active(data.get("items", [])) if x.get("applicable") is not False]
        inspections = active(data.get("inspections", []))
        findings = active(data.get("findings", []))
        attachments = active(data.get("attachments", []))
        company_map, item_map, inspection_map = self._company_maps(data)

        att_paths: Dict[Tuple[str, str], List[str]] = {}
        for a in attachments:
            key = (str(a.get("entityType") or ""), str(a.get("entityId") or ""))
            rel = str(a.get("relativePath") or "").replace("\\", "/").lstrip("/")
            if rel:
                att_paths.setdefault(key, []).append(rel)
        for key in list(att_paths):
            att_paths[key] = sorted(set(att_paths[key]))

        kw = self._excel_state_kwargs()
        item_state = {str(x.get("id")): self._excel_item_state(x, **kw) for x in items}

        def link_for_rel(rel: str, label: str = "فتح المرفق", folder: bool = False) -> Any:
            rel = str(rel or "").replace("\\", "/").lstrip("/")
            if not rel:
                return ""
            path_rel = str(Path(rel).parent).replace("\\", "/") if folder else rel
            if relative_links:
                target = path_rel
            else:
                try:
                    target = (self.paths["root"] / path_rel).resolve().as_uri()
                except Exception:
                    target = str((self.paths["root"] / path_rel).resolve())
            return {"__hyperlink__": target, "text": label}

        def finding_paths(f: Dict[str, Any]) -> List[str]:
            paths = list(att_paths.get(("finding", str(f.get("id"))), []))
            for role in ("before", "after"):
                rel = str(f.get(f"_{role}PhotoPath") or "").replace("\\", "/").lstrip("/")
                if rel:
                    paths.append(rel)
            return sorted(set(paths))

        # -------- الرئيسية: same KPI blocks + follow-up tables --------
        states = list(item_state.values())
        relevant_open = [f for f in findings if f.get("status") != "Closed"]
        dashboard_rows: List[List[Any]] = [
            ["برنامج متابعة الشركات والتفتيشات — Sokhna Port", "", "", "", "", "", "", ""],
            ["آخر تحديث", dt.datetime.now().strftime("%d/%m/%Y %H:%M"), "", "", "", "", "", ""],
            ["Dashboard البنود", "", "", "", "", "", "", ""],
            ["إجمالي البنود", "منتهية", "قريبة الانتهاء", "سارية", "", "", "", ""],
            [len(items), states.count("منتهية"), states.count("قريبة الانتهاء"), states.count("سارية"), "", "", "", ""],
            ["Dashboard التفتيشات", "", "", "", "", "", "", ""],
            ["إجمالي التفتيشات", "بنود NCR مفتوحة", "إجمالي بنود NCR", "بنود NCR مغلقة", "", "", "", ""],
            [len(inspections), len(relevant_open), len(findings), sum(1 for f in findings if f.get("status") == "Closed"), "", "", "", ""],
            ["بنود تحتاج متابعة", "", "", "", "", "", "", ""],
        ]
        dashboard_styles: Dict[Tuple[int, int], int] = {}
        dashboard_merges = [(1,1,1,8),(3,1,3,8),(6,1,6,8),(9,1,9,8)]
        for c in range(1,9): dashboard_styles[(1,c)] = 3
        for c in range(1,9): dashboard_styles[(3,c)] = dashboard_styles[(6,c)] = dashboard_styles[(9,c)] = 12
        for c in range(1,5):
            dashboard_styles[(4,c)] = dashboard_styles[(7,c)] = 1
            dashboard_styles[(5,c)] = dashboard_styles[(8,c)] = 2
        r = len(dashboard_rows)
        attention_by_company: Dict[str,List[Dict[str,Any]]] = {}
        for it in items:
            if item_state.get(str(it.get("id"))) in ("منتهية", "قريبة الانتهاء"):
                attention_by_company.setdefault(str(it.get("companyId") or ""), []).append(it)
        if not attention_by_company:
            dashboard_rows.append(["لا توجد بنود منتهية أو قريبة الانتهاء", "", "", "", "", "", "", ""])
            dashboard_merges.append((r+1,1,r+1,8)); dashboard_styles[(r+1,1)] = 4; r += 1
        for cid in sorted(attention_by_company, key=lambda x: str((company_map.get(x) or {}).get("name") or "")):
            arr = sorted(attention_by_company[cid], key=lambda x: (int(x.get("position") or 999999), str(x.get("name") or "")))
            r += 1
            dashboard_rows.append([(company_map.get(cid) or {}).get("name", "شركة غير معروفة"), "", "", "", "", "", "", ""])
            dashboard_merges.append((r,1,r,8))
            for c in range(1,9): dashboard_styles[(r,c)] = 6
            r += 1
            dashboard_rows.append(["م", "البند", "تاريخ الإصدار", "تاريخ الانتهاء", "مرفقات", "الموقف الحالي", "تعديل", "الحالة"])
            for c in range(1,9): dashboard_styles[(r,c)] = 1
            for no,it in enumerate(arr,1):
                paths = att_paths.get(("item",str(it.get("id"))),[])
                link = link_for_rel(paths[0], f"فتح المرفقات ({len(paths)})", folder=True) if paths else "—"
                state = item_state.get(str(it.get("id")), "")
                r += 1
                dashboard_rows.append([no,it.get("name",""),self._display_date(it.get("issueDate")),"بدون انتهاء" if it.get("noExpiry") else self._display_date(it.get("expiryDate")),link,it.get("currentStatus",""),"—",state])
                for c in (1,3,4,5,7,8): dashboard_styles[(r,c)] = 11
                dashboard_styles[(r,8)] = 7 if state=="منتهية" else 8 if state=="قريبة الانتهاء" else 9
        r += 1
        dashboard_rows.append(["NCR تحتاج متابعة", "", "", "", "", "", "", ""])
        dashboard_merges.append((r,1,r,8))
        for c in range(1,9): dashboard_styles[(r,c)] = 12
        open_by_company: Dict[str,List[Dict[str,Any]]] = {}
        for f in relevant_open:
            ins = inspection_map.get(str(f.get("inspectionId"))) or {}
            open_by_company.setdefault(str(ins.get("companyId") or ""), []).append(f)
        if not open_by_company:
            r += 1; dashboard_rows.append(["لا توجد بنود NCR مفتوحة", "", "", "", "", "", "", ""]); dashboard_merges.append((r,1,r,8)); dashboard_styles[(r,1)] = 4
        for cid in sorted(open_by_company, key=lambda x: str((company_map.get(x) or {}).get("name") or "")):
            arr = open_by_company[cid]
            r += 1; dashboard_rows.append([(company_map.get(cid) or {}).get("name", "شركة غير معروفة"), "", "", "", "", "", "", ""]); dashboard_merges.append((r,1,r,8))
            for c in range(1,9): dashboard_styles[(r,c)] = 6
            r += 1; dashboard_rows.append(["م", "الملاحظة", "تاريخ التفتيش", "كود التفتيش", "مرفقات", "الحالة", "تعديل", "حذف"])
            for c in range(1,9): dashboard_styles[(r,c)] = 1
            for no,f in enumerate(arr,1):
                ins = inspection_map.get(str(f.get("inspectionId"))) or {}; paths=finding_paths(f)
                link=link_for_rel(paths[0],f"فتح المرفقات ({len(paths)})",folder=True) if paths else "—"
                r+=1; dashboard_rows.append([no,f.get("description") or f.get("requirement") or "",self._display_date(ins.get("date")),ins.get("inspectionCode") or ins.get("inspectionNo") or "",link,self._excel_status_ar(f.get("status")),"—","—"])
                for c in (1,3,4,5,6,7,8): dashboard_styles[(r,c)] = 11
        dashboard={"name":"الرئيسية","rows":dashboard_rows,"widths":[7,52,17,21,18,34,12,16],"styles":dashboard_styles,"merges":dashboard_merges,"freeze":2}

        # -------- إدارة الشركات --------
        dynamic_labels: List[Tuple[str,str]]=[]; seen=set()
        for c in companies:
            for f in c.get("profileFields",[]) if isinstance(c.get("profileFields"),list) else []:
                key=str(f.get("key") or f.get("id") or f.get("label") or ""); label=str(f.get("label") or key or "بيان")
                if key and key not in seen: dynamic_labels.append((key,label)); seen.add(key)
        company_rows=[["إدارة الشركات", "", ""] + [""]*len(dynamic_labels), ["م","رقم الشركة","اسم الشركة"]+[label for _,label in dynamic_labels]]
        company_styles={(1,c):12 for c in range(1,4+len(dynamic_labels))}; company_merges=[(1,1,1,3+len(dynamic_labels))]
        for idx,c in enumerate(sorted(companies,key=lambda x:int(x.get("companySerial") or 999999)),1):
            fields=c.get("profileFields") if isinstance(c.get("profileFields"),list) else []; fmap={str(f.get("key") or f.get("id") or f.get("label") or ""):f for f in fields}; vals=[]
            for key,_ in dynamic_labels:
                f=fmap.get(key); vals.append(self._company_profile_value(c,f,item_map) if f else str(c.get(key) or ""))
            company_rows.append([idx,c.get("companySerial",""),c.get("name","")]+vals)
        companies_sheet={"name":"إدارة الشركات","rows":company_rows,"widths":[7,12,34]+[28]*len(dynamic_labels),"styles":company_styles,"merges":company_merges,"header_rows":[2],"freeze":2,"autofilter":True,"autofilter_row":2}

        # -------- بنود الشركات: grouped exactly like the program --------
        item_rows=[["بنود الشركات", "", "", "", "", "", ""]]; item_styles={(1,c):12 for c in range(1,8)}; item_merges=[(1,1,1,7)]; rr=1
        grouped:Dict[str,List[Dict[str,Any]]]={}
        for it in items: grouped.setdefault(str(it.get("companyId") or ""),[]).append(it)
        for cid in sorted(grouped,key=lambda x:str((company_map.get(x) or {}).get("name") or "")):
            arr=sorted(grouped[cid],key=lambda x:(int(x.get("position") or 999999),str(x.get("name") or "")))
            rr+=1; item_rows.append([(company_map.get(cid) or {}).get("name","شركة غير معروفة"),"","","","","",""]); item_merges.append((rr,1,rr,7))
            for c in range(1,8): item_styles[(rr,c)]=6
            rr+=1; item_rows.append(["م","البند","تاريخ الإصدار","تاريخ الانتهاء","مرفقات","الموقف الحالي","تعديل"])
            for c in range(1,8): item_styles[(rr,c)]=1
            for no,it in enumerate(arr,1):
                paths=att_paths.get(("item",str(it.get("id"))),[]); link=link_for_rel(paths[0],f"فتح المرفقات ({len(paths)})",folder=True) if paths else "—"; state=item_state.get(str(it.get("id")),"")
                rr+=1; item_rows.append([no,it.get("name",""),self._display_date(it.get("issueDate")),"بدون انتهاء" if it.get("noExpiry") else self._display_date(it.get("expiryDate")),link,it.get("currentStatus","") or state,"—"])
                for c in (1,3,4,5,7): item_styles[(rr,c)]=11
                item_styles[(rr,6)]=7 if state=="منتهية" else 8 if state=="قريبة الانتهاء" else 9 if state=="سارية" else 4
        items_sheet={"name":"بنود الشركات","rows":item_rows,"widths":[7,55,17,20,18,36,12],"styles":item_styles,"merges":item_merges,"freeze":1}

        # -------- التفتيشات --------
        inspection_rows=[["التفتيشات", "", "", "", "", "", "", ""]]; inspection_styles={(1,c):12 for c in range(1,9)}; inspection_merges=[(1,1,1,8)]; rr=1
        insp_group:Dict[str,List[Dict[str,Any]]]={}
        for ins in inspections: insp_group.setdefault(str(ins.get("companyId") or ""),[]).append(ins)
        for cid in sorted(insp_group,key=lambda x:str((company_map.get(x) or {}).get("name") or "")):
            arr=sorted(insp_group[cid],key=lambda x:str(x.get("date") or ""),reverse=True)
            rr+=1; inspection_rows.append([(company_map.get(cid) or {}).get("name","شركة غير معروفة"),"","","","","","",""]); inspection_merges.append((rr,1,rr,8))
            for c in range(1,9): inspection_styles[(rr,c)]=6
            rr+=1; inspection_rows.append(["م","تاريخ التفتيش","كود التفتيش","نوع التفتيش","NCR مفتوح","NCR مغلق","إجمالي NCR","ملاحظات"])
            for c in range(1,9): inspection_styles[(rr,c)]=1
            for no,ins in enumerate(arr,1):
                fs=[f for f in findings if str(f.get("inspectionId"))==str(ins.get("id"))]; op=sum(1 for f in fs if f.get("status")!="Closed"); cl=sum(1 for f in fs if f.get("status")=="Closed")
                rr+=1; inspection_rows.append([no,self._display_date(ins.get("date")),ins.get("inspectionCode") or ins.get("inspectionNo") or "",ins.get("type",""),op,cl,len(fs),ins.get("notes","")])
                for c in (1,2,3,5,6,7): inspection_styles[(rr,c)]=11
        inspections_sheet={"name":"التفتيشات","rows":inspection_rows,"widths":[7,17,22,24,14,14,14,50],"styles":inspection_styles,"merges":inspection_merges,"freeze":1}

        # -------- NCR details --------
        finding_rows=[["NCR — بنود عدم المطابقة", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""], ["م","الشركة","كود التفتيش","تاريخ التفتيش","رقم البند","التصنيف","البند / المتطلب","المرجع","الملاحظة","الإجراء المطلوب","السبب الجذري","المسؤول","تاريخ الالتزام","الحالة","تاريخ الإنجاز الفعلي","المرفقات"]]
        finding_styles={(1,c):12 for c in range(1,17)}; finding_merges=[(1,1,1,16)]
        sorted_findings=sorted(findings,key=lambda f:(str((inspection_map.get(str(f.get("inspectionId"))) or {}).get("date") or ""),int(str(f.get("no") or "0") or 0)))
        for idx,f in enumerate(sorted_findings,1):
            ins=inspection_map.get(str(f.get("inspectionId"))) or {}; comp=company_map.get(str(ins.get("companyId"))) or {}; paths=finding_paths(f); link=link_for_rel(paths[0],f"فتح المرفقات ({len(paths)})",folder=True) if paths else "—"
            finding_rows.append([idx,comp.get("name",""),ins.get("inspectionCode") or ins.get("inspectionNo") or "",self._display_date(ins.get("date")),f.get("no",""),f.get("classification",""),f.get("requirement",""),f.get("referenceNo",""),f.get("description",""),f.get("requiredAction",""),f.get("rootCause",""),f.get("responsible",""),self._display_date(f.get("targetDate")),self._excel_status_ar(f.get("status")),self._display_date(f.get("actualCompletionDate") or f.get("closeDate")),link])
            rowno=len(finding_rows); finding_styles[(rowno,14)]=7 if f.get("status") not in ("Closed",) else 9
            for c in (1,3,4,5,12,13,14,15,16): finding_styles[(rowno,c)]=11 if c!=14 else finding_styles[(rowno,14)]
        findings_sheet={"name":"NCR","rows":finding_rows,"widths":[7,28,21,17,10,14,38,18,52,44,34,26,17,14,18,18],"styles":finding_styles,"merges":finding_merges,"header_rows":[2],"freeze":2,"autofilter":True,"autofilter_row":2}

        # -------- Attachments page with a direct link on every physical attachment --------
        attachment_rows=[["المرفقات", "", "", "", "", "", "", ""], ["م","الشركة","نوع السجل","السجل","اسم الملف","الحجم","فتح المرفق","المسار الفعلي"]]
        attachment_styles={(1,c):12 for c in range(1,9)}; attachment_merges=[(1,1,1,8)]
        et_ar={"company":"الشركة","item":"بند الشركة","inspection":"التفتيش","finding":"NCR","ncr":"NCR"}; ax=0
        for a in attachments:
            ax+=1; et=str(a.get("entityType") or ""); eid=str(a.get("entityId") or ""); comp,rec,label=self._company_for_attachment_without_cursor(data,et,eid); rel=str(a.get("relativePath") or ""); full=str((self.paths["root"] / rel).resolve()) if rel else ""
            attachment_rows.append([ax,(comp or {}).get("name",""),et_ar.get(et,et),label,a.get("filename",""),a.get("size",""),link_for_rel(rel),full])
        for f in findings:
            ins=inspection_map.get(str(f.get("inspectionId"))) or {}; comp=company_map.get(str(ins.get("companyId"))) or {}; label=f"NCR {f.get('no') or ''} - {ins.get('inspectionCode') or ins.get('inspectionNo') or ''}"
            for role,ar in (("before","صورة قبل"),("after","صورة بعد")):
                rel=str(f.get(f"_{role}PhotoPath") or "")
                if not rel: continue
                ax+=1; full=str((self.paths["root"] / rel).resolve()); attachment_rows.append([ax,comp.get("name",""),"NCR",label,ar,f.get(f"_{role}PhotoSize") or "",link_for_rel(rel),full])
        attachments_sheet={"name":"المرفقات","rows":attachment_rows,"widths":[7,28,18,44,34,14,18,72],"styles":attachment_styles,"merges":attachment_merges,"header_rows":[2],"freeze":2,"autofilter":True,"autofilter_row":2}

        # -------- Master list and inspection checklist --------
        master_rows=[["Master Items", "", "", "", ""],["م","الرقم المرجعي","اسم البند","الترتيب","الحالة"]]
        for idx,m in enumerate(sorted(active(data.get("masterItems",[])),key=lambda x:int(x.get("position") or 999999)),1): master_rows.append([idx,m.get("referenceNo",""),m.get("name",""),m.get("position",""),"نشط"])
        master_sheet={"name":"Master Items","rows":master_rows,"widths":[7,18,60,12,14],"styles":{(1,c):12 for c in range(1,6)},"merges":[(1,1,1,5)],"header_rows":[2],"freeze":2,"autofilter":True,"autofilter_row":2}
        insp_master_rows=[["قائمة مراجعة التفتيش", "", "", "", ""],["م","الرقم المرجعي","بند قائمة المراجعة","الترتيب","الحالة"]]
        for idx,m in enumerate(sorted(active(data.get("inspectionMasterItems",[])),key=lambda x:int(x.get("position") or 999999)),1): insp_master_rows.append([idx,m.get("referenceNo",""),m.get("name",""),m.get("position",""),"نشط"])
        insp_master_sheet={"name":"قائمة مراجعة التفتيش","rows":insp_master_rows,"widths":[7,18,72,12,14],"styles":{(1,c):12 for c in range(1,6)},"merges":[(1,1,1,5)],"header_rows":[2],"freeze":2,"autofilter":True,"autofilter_row":2}

        # -------- Sync / storage + settings pages --------
        h=self.health()
        sync_rows=[["المزامنة والتخزين", ""],["البند","القيمة"],["الإصدار",APP_VERSION],["مكان البيانات",str(self.paths["root"])],["قاعدة البيانات",str(self.db_path)],["المرفقات",str(self.paths["attachments"])],["مجلد Excel",str(self.excel_export_root())],["Excel المباشر",str(self.live_excel_path())],["فحص SQLite",h.get("quickCheck","")],["آخر Daily Backup",h.get("lastDailyBackup","")],["آخر Weekly Backup",h.get("lastWeeklyBackup","")],["آخر Weekly Recovery",h.get("lastWeeklyRecovery","")]]
        sync_sheet={"name":"المزامنة والتخزين","rows":sync_rows,"widths":[28,95],"styles":{(1,1):12,(1,2):12},"merges":[(1,1,1,2)],"header_rows":[2],"freeze":2}
        xs=self.excel_settings(); settings_rows=[["الإعدادات", ""],["الإعداد","القيمة"],["التحذير الأصفر قبل الانتهاء — يوم",xs.get("yellowDays",60)],["التحذير الأحمر قبل/عند الانتهاء — يوم",xs.get("redDays",0)],["إصدار البرنامج",APP_VERSION]]
        settings_sheet={"name":"الإعدادات","rows":settings_rows,"widths":[46,44],"styles":{(1,1):12,(1,2):12},"merges":[(1,1,1,2)],"header_rows":[2],"freeze":2}

        # Hidden lossless source records for audit/recovery tooling.
        raw_rows=[["المخزن","المعرف","JSON_FULL"]]
        for store in STORES:
            for rec in data.get(store,[]): raw_rows.append([store,rec.get("id",""),json.dumps(rec,ensure_ascii=False,separators=(",",":"))])
        raw_sheet={"name":"بيانات الاستعادة","rows":raw_rows,"widths":[24,42,120],"header_rows":[1],"freeze":1,"hidden":True}

        return [dashboard,companies_sheet,items_sheet,inspections_sheet,findings_sheet,attachments_sheet,master_sheet,insp_master_sheet,sync_sheet,settings_sheet,raw_sheet]

    def _company_for_attachment_without_cursor(self, data: Dict[str,List[Dict[str,Any]]], et: str, eid: str) -> Tuple[Optional[Dict[str,Any]], Optional[Dict[str,Any]], str]:
        companies={str(x.get("id")):x for x in data.get("companies",[]) if x.get("id")}
        items={str(x.get("id")):x for x in data.get("items",[]) if x.get("id")}
        inspections={str(x.get("id")):x for x in data.get("inspections",[]) if x.get("id")}
        findings={str(x.get("id")):x for x in data.get("findings",[]) if x.get("id")}
        ncrs={str(x.get("id")):x for x in data.get("ncrs",[]) if x.get("id")}
        if et=="company":
            c=companies.get(eid); return c,c,"مرفقات الشركة"
        if et=="item":
            r=items.get(eid); c=companies.get(str((r or {}).get("companyId") or "")); return c,r,str((r or {}).get("name") or "بند")
        if et=="inspection":
            r=inspections.get(eid); c=companies.get(str((r or {}).get("companyId") or "")); code=(r or {}).get("inspectionCode") or (r or {}).get("inspectionNo") or (r or {}).get("date") or "تفتيش"; return c,r,f"تفتيش - {code}"
        if et in ("finding","ncr"):
            r=(findings if et=="finding" else ncrs).get(eid); ins=inspections.get(str((r or {}).get("inspectionId") or "")); c=companies.get(str((ins or {}).get("companyId") or "")); code=(ins or {}).get("inspectionCode") or (ins or {}).get("inspectionNo") or "تفتيش"; no=(r or {}).get("no") or ""; req=(r or {}).get("requirement") or (r or {}).get("description") or "ملاحظة"; return c,r,f"NCR {no} - {code} - {req}"
        return None,None,et or "مرفقات"

    @staticmethod
    def _xlsx_col_name(n: int) -> str:
        out=""
        while n:
            n,r=divmod(n-1,26); out=chr(65+r)+out
        return out

    def _write_program_xlsx(self, out: Path, relative_links: bool = False) -> Path:
        sheets=self._program_excel_sheets(relative_links=relative_links)
        out.parent.mkdir(parents=True,exist_ok=True)
        tmp=out.with_name(out.name+".tmp")
        content_types=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">','<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>','<Default Extension="xml" ContentType="application/xml"/>','<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>','<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
        for i in range(len(sheets)): content_types.append(f'<Override PartName="/xl/worksheets/sheet{i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>')
        content_types.append('</Types>')
        root_rels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
        wb_sheets=[]; wb_rels=[]
        for i,sh in enumerate(sheets,1):
            state=' state="hidden"' if sh.get("hidden") else ''
            wb_sheets.append(f'<sheet name="{html.escape(str(sh["name"])[:31],quote=True)}" sheetId="{i}"{state} r:id="rId{i}"/>')
            wb_rels.append(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>')
        styles_id=len(sheets)+1
        wb_rels.append(f'<Relationship Id="rId{styles_id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>')
        workbook='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets>'+''.join(wb_sheets)+'</sheets></workbook>'
        workbook_rels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(wb_rels)+'</Relationships>'
        styles="""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="5"><font><sz val="11"/><name val="Tahoma"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Tahoma"/></font><font><b/><sz val="20"/><color rgb="FF0F4C81"/><name val="Tahoma"/></font><font><b/><sz val="15"/><color rgb="FF17202A"/><name val="Tahoma"/></font><font><u/><sz val="11"/><color rgb="FF1D4ED8"/><name val="Tahoma"/></font></fonts><fills count="10"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF0F4C81"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF5F7FA"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFEAF2FF"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FF0B3760"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFDEAEA"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFF6DC"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE9F7EE"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFEEF7FF"/></patternFill></fill></fills><borders count="2"><border/><border><left style="thin"><color rgb="FFE4E7EC"/></left><right style="thin"><color rgb="FFE4E7EC"/></right><top style="thin"><color rgb="FFE4E7EC"/></top><bottom style="thin"><color rgb="FFE4E7EC"/></bottom></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="13"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"><alignment horizontal="right" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="3" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="2" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"><alignment horizontal="right" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="1" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="right" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="3" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="3" fillId="7" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="3" fillId="8" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="4" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="3" fillId="9" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="right" vertical="center" wrapText="1"/></xf></cellXfs></styleSheet>"""
        try:
            with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,allowZip64=True) as z:
                z.writestr('[Content_Types].xml',''.join(content_types)); z.writestr('_rels/.rels',root_rels); z.writestr('xl/workbook.xml',workbook); z.writestr('xl/_rels/workbook.xml.rels',workbook_rels); z.writestr('xl/styles.xml',styles)
                for idx,sh in enumerate(sheets,1):
                    rows=sh.get('rows') or []; widths=sh.get('widths') or []; style_map=sh.get('styles') or {}; header_rows=set(sh.get('header_rows') or [])
                    max_cols=max([len(r) for r in rows]+[1])
                    cols=''.join(f'<col min="{c}" max="{c}" width="{float(widths[c-1] if c-1<len(widths) else 18):.1f}" customWidth="1"/>' for c in range(1,max_cols+1))
                    xml_rows=[]
                    for rno,row in enumerate(rows,1):
                        cells=[]
                        for cno,value in enumerate(row,1):
                            ref=f'{self._xlsx_col_name(cno)}{rno}'
                            st=int(style_map.get((rno,cno),1 if rno in header_rows else 4))
                            if isinstance(value,dict) and value.get("__hyperlink__"):
                                if (rno,cno) not in style_map: st=10
                                target=str(value.get("__hyperlink__") or "").replace('"','""')
                                label=str(value.get("text") or "فتح المرفق").replace('"','""')
                                formula=html.escape(f'HYPERLINK("{target}","{label}")',quote=False)
                                cached=self._xlsx_xml_escape(label)
                                cells.append(f'<c r="{ref}" t="str" s="{st}"><f>{formula}</f><v>{cached}</v></c>')
                            elif isinstance(value,(int,float)) and not isinstance(value,bool):
                                cells.append(f'<c r="{ref}" s="{st}"><v>{value}</v></c>')
                            else:
                                text=self._xlsx_xml_escape(value)
                                cells.append(f'<c r="{ref}" t="inlineStr" s="{st}"><is><t xml:space="preserve">{text}</t></is></c>')
                        row_style_values={int(style_map.get((rno,c),-1)) for c in range(1,max_cols+1)}
                        if rno in header_rows: height=' ht="30" customHeight="1"'
                        elif 3 in row_style_values: height=' ht="38" customHeight="1"'
                        elif 6 in row_style_values or 12 in row_style_values: height=' ht="28" customHeight="1"'
                        else: height=''
                        xml_rows.append(f'<row r="{rno}"{height}>{"".join(cells)}</row>')
                    merges=sh.get('merges') or []
                    merge_xml=''
                    if merges:
                        refs=[]
                        for r1,c1,r2,c2 in merges: refs.append(f'{self._xlsx_col_name(c1)}{r1}:{self._xlsx_col_name(c2)}{r2}')
                        merge_xml=f'<mergeCells count="{len(refs)}">'+''.join(f'<mergeCell ref="{x}"/>' for x in refs)+'</mergeCells>'
                    pane=''
                    if sh.get('freeze'):
                        fr=int(sh.get('freeze')); pane=f'<pane ySplit="{fr}" topLeftCell="A{fr+1}" activePane="bottomLeft" state="frozen"/>'
                    autofilter=''
                    if sh.get('autofilter') and rows:
                        afr=int(sh.get('autofilter_row') or 1)
                        end_ref=f'{self._xlsx_col_name(max_cols)}{len(rows)}'; autofilter=f'<autoFilter ref="A{afr}:{end_ref}"/>'
                    sheet_xml=f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView rightToLeft="1" workbookViewId="0">{pane}</sheetView></sheetViews><sheetFormatPr defaultRowHeight="22"/><cols>{cols}</cols><sheetData>{''.join(xml_rows)}</sheetData>{merge_xml}{autofilter}</worksheet>"""
                    z.writestr(f'xl/worksheets/sheet{idx}.xml',sheet_xml)
            os.replace(tmp,out)
        except Exception:
            try: tmp.unlink(missing_ok=True)
            except Exception: pass
            raise
        return out

    def live_excel_path(self) -> Path:
        return self.excel_export_root() / "Sokhna_Port_Live.xlsx"

    def refresh_live_excel_now(self) -> Path:
        out=self.live_excel_path()
        self._write_program_xlsx(out)
        self._last_excel_error=""; self._last_excel_update=now_iso()
        return out

    def create_recovery_xlsx(self, category: str = "Manual") -> Path:
        cat=category.upper(); dest_dir=self.paths["recovery_weekly"] if cat=="WEEKLY" else self.paths["recovery_manual"]; prefix="WEEKLY" if cat=="WEEKLY" else "MANUAL"
        dest_dir.mkdir(parents=True,exist_ok=True)
        out=dest_dir/f"{prefix}_RECOVERY_{stamp()}.xlsx"
        return self._write_program_xlsx(out)

    def export_excel_package(self) -> Dict[str, Any]:
        self.organize_existing_attachments()
        root=self.excel_export_root(); base=root/f"تصدير_Sokhna_Port_{stamp()}"; folder=base; seq=2
        while folder.exists():
            folder=Path(str(base)+f"_{seq}"); seq+=1
        folder.mkdir(parents=True,exist_ok=False)
        xlsx=self._write_program_xlsx(folder/"Sokhna_Port_Export.xlsx", relative_links=True)
        dst=folder/"Attachments"; file_count=0
        refs: set[str] = set()
        data = self.all_data()
        for a in data.get("attachments", []):
            rel = str(a.get("relativePath") or "").replace("\\", "/").lstrip("/")
            if rel.startswith("Attachments/"):
                refs.add(rel)
        for f in data.get("findings", []):
            for role in ("before", "after"):
                rel = str(f.get(f"_{role}PhotoPath") or "").replace("\\", "/").lstrip("/")
                if rel.startswith("Attachments/"):
                    refs.add(rel)
        for rel in sorted(refs):
            src_file = (self.paths["root"] / rel).resolve()
            try:
                if not src_file.is_file() or self.paths["attachments"].resolve() not in src_file.parents:
                    continue
                target = folder / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_file, target)
                file_count += 1
            except Exception:
                continue
        info={"type":"Sokhna Port Excel + Attachments Export","version":APP_VERSION,"createdAt":now_iso(),"excel":xlsx.name,"attachments":file_count}
        (folder/"EXPORT_INFO.json").write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
        return {"folder":str(folder),"excel":str(xlsx),"attachments":file_count}

    @staticmethod
    def retain(directory: Path, pattern: str, keep: int) -> None:
        files = sorted(directory.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
        for p in files[keep:]:
            try:
                p.unlink()
            except Exception:
                pass

    def automatic_maintenance(self) -> Dict[str, str]:
        result: Dict[str, str] = {}
        today = dt.date.today()
        daily_tag = today.strftime("%Y%m%d")
        if not list(self.paths["daily"].glob(f"DAILY_BACKUP_{daily_tag}_*.zip")):
            result["daily"] = str(self.create_backup("DAILY"))
        iso = today.isocalendar()
        weekly_marker = f"{iso.year}-W{iso.week:02d}"
        weekly_meta = self.paths["weekly"] / ".last_weekly.txt"
        old = weekly_meta.read_text(encoding="utf-8").strip() if weekly_meta.exists() else ""
        if old != weekly_marker:
            result["weekly"] = str(self.create_backup("WEEKLY"))
            result["recoveryWeekly"] = str(self.create_recovery_xlsx("WEEKLY"))
            weekly_meta.write_text(weekly_marker, encoding="utf-8")
        self.retain(self.paths["daily"], "DAILY_BACKUP_*.zip", 7)
        self.retain(self.paths["weekly"], "WEEKLY_BACKUP_*.zip", 4)
        self.retain(self.paths["recovery_weekly"], "WEEKLY_RECOVERY_*.xlsx", 4)
        return result

    def health(self) -> Dict[str, Any]:
        with self.lock:
            q = self.conn.execute("PRAGMA quick_check").fetchone()
            counts = {s: self.conn.execute("SELECT COUNT(*) FROM records WHERE store=?", (s,)).fetchone()[0] for s in STORES}
        def newest(folder: Path, glob: str) -> str:
            arr = sorted(folder.glob(glob), key=lambda p: p.stat().st_mtime, reverse=True)
            return arr[0].name if arr else ""
        return {
            "ok": True,
            "appVersion": APP_VERSION,
            "schemaVersion": SCHEMA_VERSION,
            "database": str(self.db_path),
            "dataRoot": str(self.paths["root"]),
            "attachmentsRoot": str(self.paths["attachments"]),
            "excelExportRoot": str(self.excel_export_root()),
            "liveExcel": str(self.live_excel_path()),
            "lastExcelUpdate": self._last_excel_update,
            "lastExcelError": self._last_excel_error,
            "quickCheck": q[0] if q else "unknown",
            "counts": counts,
            "lastDailyBackup": newest(self.paths["daily"], "DAILY_BACKUP_*.zip"),
            "lastWeeklyBackup": newest(self.paths["weekly"], "WEEKLY_BACKUP_*.zip"),
            "lastWeeklyRecovery": newest(self.paths["recovery_weekly"], "WEEKLY_RECOVERY_*.xlsx"),
        }


STORE: DesktopStore


class Handler(BaseHTTPRequestHandler):
    server_version = "CompanyInspectionDesktop/4.8.16.7-R3"

    def log_message(self, fmt: str, *args: Any) -> None:
        try:
            log = STORE.paths["logs"] / "server.log"
            with open(log, "a", encoding="utf-8") as f:
                f.write(f"{dt.datetime.now().isoformat(timespec='seconds')} {self.address_string()} {fmt % args}\n")
        except Exception:
            pass

    def _send_json(self, obj: Any, status: int = 200) -> None:
        raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _error(self, exc: Exception, status: int = 400) -> None:
        self._send_json({"ok": False, "error": str(exc)}, status)

    def _read_json(self) -> Any:
        try:
            n = int(self.headers.get("Content-Length", "0") or 0)
        except ValueError:
            n = 0
        if n <= 0 or n > MAX_JSON_BODY:
            raise ValueError("حجم الطلب غير صالح")
        raw = self.rfile.read(n)
        return json.loads(raw.decode("utf-8"))

    def _serve_file(self, path: Path, download_name: Optional[str] = None, mime: Optional[str] = None) -> None:
        if not path.is_file():
            self.send_error(404)
            return
        ctype = mime or mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        size = path.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(size))
        self.send_header("Cache-Control", "no-store")
        if download_name:
            quoted = urllib.parse.quote(download_name)
            self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{quoted}")
        self.end_headers()
        with open(path, "rb") as f:
            shutil.copyfileobj(f, self.wfile, length=1024 * 1024)

    def do_GET(self) -> None:
        try:
            u = urllib.parse.urlparse(self.path)
            path = u.path
            q = urllib.parse.parse_qs(u.query)
            if path == "/api/health":
                self._send_json(STORE.health())
                return
            if path.startswith("/api/store/"):
                parts = path.strip("/").split("/")
                if len(parts) < 3:
                    raise ValueError("مسار غير صالح")
                store = parts[2]
                if len(parts) == 3:
                    self._send_json({"ok": True, "rows": STORE.get_all(store)})
                else:
                    rec_id = urllib.parse.unquote("/".join(parts[3:]))
                    self._send_json({"ok": True, "row": STORE.get_one(store, rec_id)})
                return
            if path == "/api/file":
                rel = urllib.parse.unquote((q.get("path") or [""])[0]).replace("\\", "/").lstrip("/")
                root = STORE.paths["root"].resolve()
                target = (root / rel).resolve()
                if root not in target.parents:
                    raise ValueError("مسار غير مسموح")
                self._serve_file(target)
                return
            if path == "/api/export":
                mode = (q.get("mode") or ["full"])[0]
                include_files = (q.get("files") or ["1"])[0] == "1"
                since = (q.get("since") or [""])[0] or None
                device_id = (q.get("deviceId") or ["computer-master"])[0]
                device_name = (q.get("deviceName") or ["الكمبيوتر الرئيسي"])[0]
                if mode == "mobile-full":
                    kind = "full-mobile-snapshot" if include_files else "full-mobile-data-only"
                    since = None
                    fname = f"MOBILE_{'FULL' if include_files else 'DATA_ONLY'}_{stamp()}.sync.json"
                elif mode == "incremental":
                    kind = "incremental-with-attachments" if include_files else "incremental-data-only"
                    fname = f"SYNC_{'FULL' if include_files else 'DATA_ONLY'}_{stamp()}.sync.json"
                elif mode == "backup":
                    kind = "full-backup"
                    since = None
                    fname = f"BACKUP_{APP_VERSION}_{stamp()}.json"
                else:
                    raise ValueError("نوع تصدير غير معروف")
                payload = STORE.export_payload(kind, include_files, since, device_id, device_name)
                raw = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Disposition", f"attachment; filename={fname}")
                self.send_header("X-Generated-At", str(payload.get("generatedAt") or ""))
                self.send_header("Content-Length", str(len(raw)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(raw)
                return

            if path == "/api/ping":
                note_heartbeat()
                self._send_json({"ok": True})
                return
            if path in ("/", ""):
                self.send_response(302)
                self.send_header("Location", "/app/index.html")
                self.end_headers()
                return
            if path.startswith("/app/"):
                rel = urllib.parse.unquote(path[len("/app/"):]) or "index.html"
                target = (WEB_ROOT / rel).resolve()
                if WEB_ROOT.resolve() not in target.parents and target != WEB_ROOT.resolve():
                    raise ValueError("مسار غير مسموح")
                self._serve_file(target)
                return
            self.send_error(404)
        except BrokenPipeError:
            pass
        except Exception as e:
            self._error(e, 400)

    def do_POST(self) -> None:
        try:
            u = urllib.parse.urlparse(self.path)
            path = u.path
            body = self._read_json()
            if path == "/api/put":
                STORE.put(str(body.get("store")), body.get("row"))
                self._send_json({"ok": True})
                return
            if path == "/api/put-many":
                STORE.put_many(str(body.get("store")), body.get("rows") or [])
                self._send_json({"ok": True})
                return
            if path == "/api/atomic-batches":
                STORE.atomic_batches(body.get("batches") or {})
                self._send_json({"ok": True})
                return
            if path == "/api/delete-many-atomic":
                STORE.delete_many_atomic(body.get("batches") or {})
                self._send_json({"ok": True})
                return
            if path == "/api/clear":
                STORE.clear(str(body.get("store")))
                self._send_json({"ok": True})
                return
            if path == "/api/delete-one":
                STORE.delete_one(str(body.get("store")), str(body.get("id")))
                self._send_json({"ok": True})
                return
            if path == "/api/replace-all":
                STORE.replace_all(body.get("data") or {})
                self._send_json({"ok": True})
                return
            if path == "/api/manual-backup":
                p = STORE.create_backup("MANUAL")
                self._send_json({"ok": True, "path": str(p), "name": p.name})
                return
            if path == "/api/manual-recovery":
                p = STORE.create_recovery_xlsx("MANUAL")
                self._send_json({"ok": True, "path": str(p), "name": p.name})
                return
            if path == "/api/choose-excel-folder":
                p, cancelled = STORE.choose_excel_export_root()
                self._send_json({"ok": True, "path": str(p), "cancelled": cancelled, "liveExcel": str(STORE.live_excel_path())})
                return
            if path == "/api/export-excel-package":
                r = STORE.export_excel_package()
                self._send_json({"ok": True, **r})
                return
            if path == "/api/excel-settings":
                STORE.set_excel_settings(body.get("yellowDays", 60), body.get("redDays", 0))
                self._send_json({"ok": True})
                return
            if path == "/api/refresh-live-excel":
                p = STORE.refresh_live_excel_now()
                self._send_json({"ok": True, "path": str(p)})
                return
            if path == "/api/move-data-root":
                raw = str(body.get("path") or "").strip()
                r = STORE.move_data_root(Path(raw)) if raw else STORE.choose_and_move_data_root()
                self._send_json({"ok": True, **r})
                return
            self.send_error(404)
        except BrokenPipeError:
            pass
        except Exception as e:
            self._error(e, 400)


def note_heartbeat() -> None:
    global LAST_HEARTBEAT, HEARTBEAT_STARTED
    with HEARTBEAT_LOCK:
        LAST_HEARTBEAT = time.time()
        HEARTBEAT_STARTED = True


def launch_app_window(url: str) -> None:
    """Open the local UI like a desktop app. No Python/Batch/external project files required."""
    if os.name == "nt":
        candidates = [
            Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Microsoft/Edge/Application/msedge.exe",
            Path(os.environ.get("PROGRAMFILES", "")) / "Microsoft/Edge/Application/msedge.exe",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft/Edge/Application/msedge.exe",
        ]
        edge = next((x for x in candidates if str(x) and x.exists()), None)
        if edge:
            profile = CONFIG_DIR / "EdgeAppProfile"
            profile.mkdir(parents=True, exist_ok=True)
            try:
                subprocess.Popen([
                    str(edge),
                    f"--app={url}",
                    f"--user-data-dir={profile}",
                    "--no-first-run",
                    "--disable-features=msEdgeSidebarV2",
                    "--start-maximized",
                ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return
            except Exception:
                pass
    webbrowser.open(url)


def start_idle_shutdown(server: ThreadingHTTPServer) -> None:
    """Close the hidden local server after the app window has been closed."""
    def worker():
        while True:
            time.sleep(5)
            with HEARTBEAT_LOCK:
                started = HEARTBEAT_STARTED
                age = time.time() - LAST_HEARTBEAT if started else 0
            if started and age > 35:
                try:
                    server.shutdown()
                except Exception:
                    pass
                return
    threading.Thread(target=worker, daemon=True).start()


def select_port(start: int) -> int:
    import socket
    for p in range(start, start + 20):
        s = socket.socket()
        try:
            s.bind(("127.0.0.1", p))
            return p
        except OSError:
            pass
        finally:
            s.close()
    raise RuntimeError("تعذر إيجاد منفذ محلي متاح لتشغيل البرنامج")


def main() -> int:
    global STORE
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", default="")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    ap.add_argument("--no-browser", action="store_true")
    args = ap.parse_args()

    # Self-contained Windows app: maintain a stable executable copy and desktop shortcut.
    ensure_installed_exe_and_shortcut()

    root = Path(args.data_root).expanduser().resolve() if args.data_root else choose_data_root()
    if os.name == "nt" and not args.data_root and not is_fixed_windows_drive(root):
        raise RuntimeError("مجلد قاعدة البيانات يجب أن يكون على هارد داخلي ثابت")
    try:
        STORE = DesktopStore(root)
    except RuntimeError as e:
        if "البرنامج مفتوح بالفعل" not in str(e):
            raise
        if focus_or_reopen_running_instance(root):
            return 0
        win_message("Sokhna Port يعمل بالفعل. انتظر لحظات ثم اضغط على الاختصار مرة أخرى.", flags=0x40)
        return 0
    try:
        port = select_port(args.port)
        server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
        # Delay automatic backup/recovery a few seconds so first-run default lists are already seeded.
        threading.Timer(8.0, lambda: STORE.automatic_maintenance()).start()
        url = f"http://127.0.0.1:{port}/app/index.html"
        write_instance_info(root, url, port)
        print("=" * 68)
        print("برنامج متابعة الشركات والتفتيشات — نسخة الكمبيوتر")
        print(f"الإصدار: {APP_VERSION}")
        print(f"قاعدة البيانات: {STORE.db_path}")
        print(f"المرفقات: {STORE.paths['attachments']}")
        print(f"الرابط المحلي: {url}")
        print("اترك هذه النافذة مفتوحة أثناء استخدام البرنامج.")
        print("=" * 68)
        start_idle_shutdown(server)
        if not args.no_browser:
            threading.Timer(0.7, lambda: launch_app_window(url)).start()
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        pass
    finally:
        remove_instance_info(root)
        try:
            remove_instance_info(STORE.paths["root"])
        except Exception:
            pass
        try:
            server.server_close()  # type: ignore[name-defined]
        except Exception:
            pass
        STORE.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
