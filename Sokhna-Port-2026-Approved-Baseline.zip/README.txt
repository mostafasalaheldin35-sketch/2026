Sokhna Port 2026 approved baseline pack

- app/index.html: extracted directly from the user-supplied Sokhna_Port_v4.8.16.9_FINAL-1 (1).exe
- app/manifest.json: extracted from the same EXE
- backend.py: verified Desktop R4 reconstruction source used as backend reference/base, not Mobile APK source
- launcher.py: minimal desktop launcher
- HASHES.json: SHA-256 verification

The exact original EXE remains the behavioral reference. Do not substitute any v4.8.16.11 UI/base.
