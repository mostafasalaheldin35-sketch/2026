import base64, sys, tempfile, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'buildsrc'))
import backend
html=(ROOT/'buildsrc/app/index.html').read_text(encoding='utf-8'); patch=(ROOT/'buildsrc/app/v2026_patch.js').read_text(encoding='utf-8')
assert "4.8.17.0-DESKTOP" in html and 'v2026_patch.js' in html
for token in ['manualStatus','subItems','غير مكتمل','غير ساري','fillNcrSources','silentSave','companyPlacement']: assert token in patch,token
root=Path(tempfile.mkdtemp(prefix='sokhna2026qa-')); st=backend.DesktopStore(root); now=backend.now_iso()
rows=[('companies',{'id':'c1','name':'شركة اختبار','companySerial':1,'profileFields':[],'createdAt':now,'modifiedAt':now,'isDeleted':False}),('items',{'id':'i1','companyId':'c1','name':'شهادات تدريب الموظفين','position':1,'issueDate':'','expiryDate':'','noExpiry':True,'manualStatus':'invalid','subItems':[{'id':'s1','name':'شهادة موظف','issueDate':'2026-01-01','expiryDate':'2026-10-15'}],'currentStatus':'','applicable':True,'createdAt':now,'modifiedAt':now,'isDeleted':False}),('inspections',{'id':'ins1','companyId':'c1','inspectionCode':'INS-1-2026-1','inspectionNo':'INS-1-2026-1','date':'2026-09-26','type':'تفتيش دوري','createdAt':now,'modifiedAt':now,'isDeleted':False}),('findings',{'id':'f1','inspectionId':'ins1','no':'1','requirement':'معدات الوقاية','referenceNo':'3.2.1','description':'اختبار','status':'Open','createdAt':now,'modifiedAt':now,'isDeleted':False}),('attachments',{'id':'a1','entityType':'item-subitem','entityId':'i1::s1','filename':'cert.pdf','mime':'application/pdf','dataUrl':'data:application/pdf;base64,'+base64.b64encode(b'PDF').decode(),'createdAt':now,'modifiedAt':now,'isDeleted':False})]
for store,row in rows: st.put(store,row)
a=st.raw_one('attachments','a1'); assert '/البنود/' in a['relativePath'] and 'شهادة موظف' in a['relativePath']
assert st._excel_item_state({'noExpiry':True,'manualStatus':'invalid'})=='غير ساري'
out=root/'company.xlsx'; st._write_program_xlsx(out,company_id='c1'); assert zipfile.is_zipfile(out)
with zipfile.ZipFile(out) as z:
    wb=z.read('xl/workbook.xml').decode('utf-8'); assert all(x in wb for x in ['بنود الشركات','التفتيشات','NCR'])
r=st.automatic_maintenance(); assert all(k in r for k in ['daily','weekly','monthly','dailyExcel','weeklyExcel','monthlyExcel'])
st.close(); print('SOKHNA 2026 QA PASSED')
