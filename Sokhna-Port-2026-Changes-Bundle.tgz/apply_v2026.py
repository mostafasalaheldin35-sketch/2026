from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]; root=root/'buildsrc'
from shutil import copy2
src_patch=Path(__file__).with_name('v2026_patch.js'); (root/'app').mkdir(parents=True,exist_ok=True); copy2(src_patch,root/'app/v2026_patch.js')
h=root/'app/index.html'; s=h.read_text(encoding='utf-8')
s=s.replace("const APP_VERSION='4.8.16.9-FINAL-DESKTOP';","const APP_VERSION='4.8.17.0-DESKTOP';",1)
css=r'''
<style id="v2026-style">
.validity-state.invalid,.item-invalid{background:#fdeaea!important;color:#b42318!important}.validity-state.nodate{background:#f2f4f7!important;color:#475467!important}.sub-summary{display:inline-flex;gap:7px;align-items:center;justify-content:center;direction:ltr}.sub-summary b{font-size:15px}.sub-summary i{font-style:normal;color:#98a2b3}.sub-ok{color:#16803c}.sub-warn{color:#b77900}.sub-bad{color:#b42318}
.v2026-date-wrap{position:relative;display:flex;gap:6px;align-items:center;width:100%}.v2026-date-native{position:absolute!important;inset:0!important;width:100%!important;height:100%!important;opacity:0!important;z-index:2;cursor:pointer}.v2026-date-display{direction:ltr!important;text-align:center!important;background:#fff!important;pointer-events:auto}.v2026-date-clear{position:relative;z-index:3;padding:7px 8px!important;border:1px solid #cfd8e3!important;background:#f8fafc!important;color:#475467!important;white-space:nowrap}
#itemDialog{width:min(98vw,1250px)!important}.subitems-section{border:1px solid #d9e2ec;border-radius:12px;padding:10px;background:#fbfdff}.subitems-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}.subitems-head h4{margin:0}.subitems-table{overflow:visible}.subitems-headrow,.subitem-row{display:grid;grid-template-columns:42px minmax(170px,1.8fr) 145px 145px 82px minmax(150px,1.5fr) 135px 42px;gap:7px;align-items:center}.subitems-headrow{font-size:12px;font-weight:700;color:#475467;padding:5px}.subitem-row{padding:5px 0;border-top:1px solid #edf1f5}.subitem-row input,.subitem-row select{min-width:0;padding:8px;border:1px solid #d0d5dd;border-radius:8px}
.sub-toggle{background:transparent!important;color:#0b5592!important;padding:2px 8px!important;font-size:18px!important}.sub-expand{display:none;margin:0 10px 8px;padding:8px;border:1px solid #dfe7ef;border-radius:10px;background:#f8fbfe}.sub-expand.open{display:block}.sub-expand-head,.sub-expand-row{display:grid;grid-template-columns:45px minmax(220px,2fr) 130px 130px 150px minmax(180px,1.5fr);gap:8px;align-items:center;padding:6px}.sub-expand-head{font-weight:700;background:#edf5fb;border-radius:7px}.sub-expand-row{border-bottom:1px solid #e8edf2}
.company-dynamic-fields{display:flex!important;flex-direction:column!important;gap:5px!important}.company-field-group-title{margin-top:9px;padding:7px 10px;background:#edf5fb;border-radius:8px;font-weight:700;color:#0b5592}.company-field-row{display:grid;grid-template-columns:28px minmax(150px,1.2fr) minmax(180px,2fr) 130px 95px 125px 36px 36px 36px;gap:6px;align-items:center;border:1px solid #e4e7ec;border-radius:9px;padding:6px;background:#fff}.company-field-row input,.company-field-row select,.company-field-value-compact input,.company-field-value-compact textarea{width:100%;min-width:0;padding:8px!important;margin:0!important}.company-field-row .drag{color:#98a2b3;text-align:center}.company-profile-section{padding:10px!important}.company-field-card{box-shadow:none!important}
@media(max-width:900px){.subitems-headrow,.subitem-row{grid-template-columns:40px minmax(180px,1fr) 130px 130px 72px minmax(150px,1fr) 125px 40px;min-width:980px}.subitems-table{overflow:auto}.company-field-row{grid-template-columns:24px minmax(130px,1fr) minmax(160px,1.5fr) 120px 85px 110px 34px 34px 34px;min-width:950px}.company-dynamic-fields{overflow:auto}}
</style>
'''
s=s.replace('</head>',css+'</head>',1)
head,tail=s.rsplit('</body>',1); s=head+'<script src=\"v2026_patch.js\"></script>\n</body>'+tail
h.write_text(s,encoding='utf-8',newline='\n')

p=root/'backend.py'; b=p.read_text(encoding='utf-8')
b=re.sub(r'^APP_VERSION\s*=\s*"[^"]+"','APP_VERSION = "4.8.17.0-DESKTOP"',b,count=1,flags=re.M)
b=b.replace('''        "weekly": root / "Backups" / "Weekly",\n        "manual": root / "Backups" / "Manual",\n        "recovery_weekly": root / "Recovery" / "Weekly",''','''        "weekly": root / "Backups" / "Weekly",\n        "monthly": root / "Backups" / "Monthly",\n        "manual": root / "Backups" / "Manual",\n        "recovery_daily": root / "Recovery" / "Daily",\n        "recovery_weekly": root / "Recovery" / "Weekly",\n        "recovery_monthly": root / "Recovery" / "Monthly",''',1)
# Replace attachment path helpers.
start=b.index('    def _friendly_attachment_rel('); end=b.index('    def organize_existing_attachments',start)
new=r'''    def _friendly_attachment_rel(self, cur: sqlite3.Cursor, entity_type: str, entity_id: str, filename: str, attachment_id: str, current_rel: str = "") -> str:
        et=str(entity_type or "").lower(); eid=str(entity_id or "")
        company=None; parts=[]
        if et=="item-subitem":
            parent_id, _, sub_id=eid.partition("::")
            item=self._get_existing_raw(cur,"items",parent_id) or {}
            company=self._get_existing_raw(cur,"companies",str(item.get("companyId") or "")) or {}
            sub=next((x for x in (item.get("subItems") or []) if str(x.get("id"))==sub_id),{})
            parts=["البنود",safe_part(item.get("name") or "بند","بند")[:80],safe_part(sub.get("name") or "بند فرعي","بند فرعي")[:80]]
        elif et=="item":
            item=self._get_existing_raw(cur,"items",eid) or {}; company=self._get_existing_raw(cur,"companies",str(item.get("companyId") or "")) or {}
            parts=["البنود",safe_part(item.get("name") or "بند","بند")[:80]]
        elif et=="inspection":
            ins=self._get_existing_raw(cur,"inspections",eid) or {}; company=self._get_existing_raw(cur,"companies",str(ins.get("companyId") or "")) or {}
            code=ins.get("inspectionCode") or ins.get("inspectionNo") or "تفتيش"; d=self._display_date(ins.get("date"))
            parts=["التفتيشات",safe_part(f"{code} - {d}","تفتيش")[:90]]
        elif et in ("finding","ncr"):
            rec=self._get_existing_raw(cur,"findings" if et=="finding" else "ncrs",eid) or {}; ins=self._get_existing_raw(cur,"inspections",str(rec.get("inspectionId") or "")) or {}; company=self._get_existing_raw(cur,"companies",str(ins.get("companyId") or "")) or {}
            code=ins.get("inspectionCode") or ins.get("inspectionNo") or "تفتيش"; d=self._display_date(ins.get("date")); req=safe_part(rec.get("requirement") or rec.get("description") or "ملاحظة","ملاحظة")[:55]
            parts=["التفتيشات",safe_part(f"{code} - {d}","تفتيش")[:90],safe_part(f"NCR {rec.get('no') or ''} - {req}","NCR")[:90]]
        elif et=="company":
            company=self._get_existing_raw(cur,"companies",eid) or {}; parts=["مرفقات الشركة"]
        else:
            company,_,label=self._company_for_record(cur,entity_type,entity_id); company=company or {}; parts=[safe_part(label,"مرفقات")[:90]]
        company_name=safe_part(company.get("name") or f"شركة_{safe_part(company.get('id') or eid)[:20]}","شركة")[:80]
        pp=Path(safe_part(filename or attachment_id or "مرفق","مرفق")); name=safe_part(pp.stem,"مرفق")[:85]+pp.suffix[:15]
        rel="/".join(["Attachments",company_name]+[safe_part(x,"مرفقات") for x in parts]+[name])
        target=self.paths["root"] / rel
        if target.exists() and current_rel.replace("\\","/")!=rel:
            suffix=safe_part(attachment_id,"id")[:8]; rel="/".join(["Attachments",company_name]+[safe_part(x,"مرفقات") for x in parts]+[f"{safe_part(pp.stem,'مرفق')} ({suffix}){pp.suffix}"])
        return rel

    def _friendly_finding_photo_rel(self, cur: sqlite3.Cursor, rec: Dict[str, Any], role: str, ext: str) -> str:
        ins=self._get_existing_raw(cur,"inspections",str(rec.get("inspectionId") or "")) or {}; company=self._get_existing_raw(cur,"companies",str(ins.get("companyId") or "")) or {}
        code=ins.get("inspectionCode") or ins.get("inspectionNo") or "تفتيش"; d=self._display_date(ins.get("date")); req=safe_part(rec.get("requirement") or rec.get("description") or "ملاحظة","ملاحظة")[:55]
        company_name=safe_part(company.get("name") or "شركة","شركة")[:80]; insp=safe_part(f"{code} - {d}","تفتيش")[:90]; ncr=safe_part(f"NCR {rec.get('no') or ''} - {req}","NCR")[:90]
        return f"Attachments/{company_name}/التفتيشات/{insp}/{ncr}/{'صورة قبل' if role=='before' else 'صورة بعد'}{ext}"

'''
b=b[:start]+new+b[end:]
# Excel item state.
pat=re.compile(r'    @staticmethod\n    def _excel_item_state\(item: Dict\[str, Any\], yellow_days: int = 60, red_days: int = 0\) -> str:\n(?:        .*\n)+?\n    @staticmethod\n    def _excel_status_ar',re.M)
rep='''    @staticmethod\n    def _excel_item_state(item: Dict[str, Any], yellow_days: int = 60, red_days: int = 0) -> str:\n        expiry=str(item.get("expiryDate") or "")[:10]\n        if expiry and not item.get("noExpiry"):\n            try:\n                exp=dt.date.fromisoformat(expiry); today=dt.date.today()\n                if exp < today: return "منتهي"\n                if exp <= today + dt.timedelta(days=60): return "قريب من الانتهاء"\n                return "ساري"\n            except Exception: return "غير مكتمل"\n        manual=str(item.get("manualStatus") or "").strip().lower()\n        if manual in ("ok","valid","ساري"): return "ساري"\n        if manual in ("invalid","not-valid","غير ساري","غيرساري"): return "غير ساري"\n        return "غير مكتمل"\n\n    @staticmethod\n    def _excel_status_ar'''
b2,n=pat.subn(rep,b,count=1)
if n!=1: raise SystemExit('excel state patch failed')
b=b2
# Add company_id parameter to excel sheets/write.
b=b.replace('def _program_excel_sheets(self, relative_links: bool = False) -> List[Dict[str, Any]]:', 'def _program_excel_sheets(self, relative_links: bool = False, company_id: str = "") -> List[Dict[str, Any]]:',1)
needle='''        attachments = active(data.get("attachments", []))\n        company_map, item_map, inspection_map = self._company_maps(data)\n'''
repl='''        attachments = active(data.get("attachments", []))\n        if company_id:\n            companies=[x for x in companies if str(x.get("id"))==str(company_id)]\n            items=[x for x in items if str(x.get("companyId"))==str(company_id)]\n            inspections=[x for x in inspections if str(x.get("companyId"))==str(company_id)]\n            ins_ids={str(x.get("id")) for x in inspections}\n            findings=[x for x in findings if str(x.get("inspectionId")) in ins_ids]\n            entity_ids={str(x.get("id")) for x in items}|{str(x.get("id")) for x in inspections}|{str(x.get("id")) for x in findings}\n            attachments=[x for x in attachments if str(x.get("entityId")) in entity_ids or (str(x.get("entityType"))=="item-subitem" and str(x.get("entityId") or "").split("::",1)[0] in entity_ids)]\n        company_map, item_map, inspection_map = self._company_maps(data)\n'''
if needle not in b: raise SystemExit('data filter anchor missing')
b=b.replace(needle,repl,1)
b=b.replace('''        return [dashboard,companies_sheet,items_sheet,inspections_sheet,findings_sheet,attachments_sheet,master_sheet,insp_master_sheet,sync_sheet,settings_sheet,raw_sheet]''','''        if company_id:\n            return [items_sheet,inspections_sheet,findings_sheet]\n        return [dashboard,companies_sheet,items_sheet,inspections_sheet,findings_sheet,attachments_sheet,master_sheet,insp_master_sheet,sync_sheet,settings_sheet,raw_sheet]''',1)
b=b.replace('def _write_program_xlsx(self, out: Path, relative_links: bool = False) -> Path:\n        sheets=self._program_excel_sheets(relative_links=relative_links)', 'def _write_program_xlsx(self, out: Path, relative_links: bool = False, company_id: str = "") -> Path:\n        sheets=self._program_excel_sheets(relative_links=relative_links, company_id=company_id)',1)
# create_backup monthly
b=b.replace('''        elif cat == "WEEKLY":\n            dest_dir = self.paths["weekly"]\n            prefix = "WEEKLY"\n        else:''','''        elif cat == "WEEKLY":\n            dest_dir = self.paths["weekly"]\n            prefix = "WEEKLY"\n        elif cat == "MONTHLY":\n            dest_dir = self.paths["monthly"]\n            prefix = "MONTHLY"\n        else:''',1)
# recovery xlsx category paths
b=b.replace('''        cat=category.upper(); dest_dir=self.paths["recovery_weekly"] if cat=="WEEKLY" else self.paths["recovery_manual"]; prefix="WEEKLY" if cat=="WEEKLY" else "MANUAL"''','''        cat=category.upper()\n        if cat=="DAILY": dest_dir=self.paths["recovery_daily"]; prefix="DAILY"\n        elif cat=="WEEKLY": dest_dir=self.paths["recovery_weekly"]; prefix="WEEKLY"\n        elif cat=="MONTHLY": dest_dir=self.paths["recovery_monthly"]; prefix="MONTHLY"\n        else: dest_dir=self.paths["recovery_manual"]; prefix="MANUAL"''',1)
# Insert per-company export + age retention before automatic_maintenance.
anchor='    def automatic_maintenance(self) -> Dict[str, str]:\n'
extra=r'''    def create_company_excel_backups(self, category: str) -> Path:
        cat=category.upper(); base=(self.paths.get(cat.lower()) or self.paths["manual"]) / (dt.date.today().isoformat()+"_Excel")
        base.mkdir(parents=True,exist_ok=True)
        data=self.all_data(); companies=[x for x in data.get("companies",[]) if not x.get("isDeleted")]
        for c in companies:
            cid=str(c.get("id") or ""); name=safe_part(c.get("name") or cid,"شركة")[:90]
            self._write_program_xlsx(base/f"{name}.xlsx", relative_links=False, company_id=cid)
        return base

    @staticmethod
    def retain_older_than(directory: Path, days: int = 90) -> None:
        cutoff=time.time()-days*86400
        if not directory.exists(): return
        for p in sorted(directory.iterdir()):
            try:
                if p.stat().st_mtime < cutoff:
                    if p.is_dir(): shutil.rmtree(p,ignore_errors=True)
                    else: p.unlink(missing_ok=True)
            except Exception: pass

'''
if anchor not in b: raise SystemExit('maintenance anchor missing')
b=b.replace(anchor,extra+anchor,1)
# Replace automatic_maintenance function body through health.
start=b.index('    def automatic_maintenance(self) -> Dict[str, str]:'); end=b.index('    def health(self) -> Dict[str, Any]:',start)
maint=r'''    def automatic_maintenance(self) -> Dict[str, str]:
        result: Dict[str, str] = {}; today=dt.date.today()
        daily_tag=today.strftime("%Y%m%d")
        if not list(self.paths["daily"].glob(f"DAILY_BACKUP_{daily_tag}_*.zip")):
            result["daily"]=str(self.create_backup("DAILY")); result["dailyExcel"]=str(self.create_company_excel_backups("DAILY"))
        iso=today.isocalendar(); weekly_marker=f"{iso.year}-W{iso.week:02d}"; wm=self.paths["weekly"] / ".last_weekly.txt"; old=wm.read_text(encoding="utf-8").strip() if wm.exists() else ""
        if old!=weekly_marker:
            result["weekly"]=str(self.create_backup("WEEKLY")); result["weeklyExcel"]=str(self.create_company_excel_backups("WEEKLY")); wm.write_text(weekly_marker,encoding="utf-8")
        monthly_marker=today.strftime("%Y-%m"); mm=self.paths["monthly"] / ".last_monthly.txt"; oldm=mm.read_text(encoding="utf-8").strip() if mm.exists() else ""
        if oldm!=monthly_marker:
            result["monthly"]=str(self.create_backup("MONTHLY")); result["monthlyExcel"]=str(self.create_company_excel_backups("MONTHLY")); mm.write_text(monthly_marker,encoding="utf-8")
        for key in ("daily","weekly","monthly","recovery_daily","recovery_weekly","recovery_monthly"):
            self.retain_older_than(self.paths[key],90)
        return result

'''
b=b[:start]+maint+b[end:]
# health monthly fields
b=b.replace('''            "lastWeeklyBackup": newest(self.paths["weekly"], "WEEKLY_BACKUP_*.zip"),\n            "lastWeeklyRecovery": newest(self.paths["recovery_weekly"], "WEEKLY_RECOVERY_*.xlsx"),''','''            "lastWeeklyBackup": newest(self.paths["weekly"], "WEEKLY_BACKUP_*.zip"),\n            "lastMonthlyBackup": newest(self.paths["monthly"], "MONTHLY_BACKUP_*.zip"),\n            "lastWeeklyRecovery": newest(self.paths["recovery_weekly"], "WEEKLY_RECOVERY_*.xlsx"),''',1)
p.write_text(b,encoding='utf-8',newline='\n')
