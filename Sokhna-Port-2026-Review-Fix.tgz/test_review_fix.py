import base64,sys,tempfile,zipfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'buildsrc';sys.path.insert(0,str(ROOT))
import backend
html=(ROOT/'app/index.html').read_text(encoding='utf-8'); js=(ROOT/'app/v2026_patch.js').read_text(encoding='utf-8')
assert '4.8.17.1-DESKTOP' in html
assert "clear.textContent='بدون تاريخ'" not in js
assert "pointerEvents='none'" in js and 'openNativeDatePicker' in js
for x in ['مسلسل','المرفقات','الموقف الحالي','الحالة','تعديل','openSubEditor','stateBadge(stateOf(s))']: assert x in js,x
assert 'toReportPlacement' in js and "inspectionReportPlacement=toReportPlacement" in js
assert 'savingPromise' in js and 'putStoreBatchesAtomic({items:[rec],attachments:rows})' in js
assert 'putStoreBatchesAtomic({findings:[rec],attachments:rows})' in js
# Backend workbook: exactly 2 sheets for one company, dates DD/MM/YYYY, children + NCR included.
root=Path(tempfile.mkdtemp(prefix='sokhna-review-')); st=backend.DesktopStore(root); now=backend.now_iso()
records=[
('companies',{'id':'c1','name':'شركة اختبار','companySerial':1,'profileFields':[],'createdAt':now,'modifiedAt':now,'isDeleted':False}),
('items',{'id':'i1','companyId':'c1','name':'تراخيص','position':1,'issueDate':'2026-01-02','expiryDate':'','noExpiry':True,'manualStatus':'ok','subItems':[{'id':'s1','name':'ترخيص فرعي','issueDate':'2026-02-03','expiryDate':'2026-12-31','manualStatus':'invalid','currentStatus':'جارٍ'}],'currentStatus':'مكتمل','applicable':True,'createdAt':now,'modifiedAt':now,'isDeleted':False}),
('inspections',{'id':'ins1','companyId':'c1','inspectionCode':'INS-1','inspectionNo':'INS-1','date':'2026-09-26','type':'دوري','notes':'ملاحظة تفتيش','createdAt':now,'modifiedAt':now,'isDeleted':False}),
('findings',{'id':'f1','inspectionId':'ins1','no':'1','requirement':'معدات الوقاية','referenceNo':'3.2.1','description':'يلزم الاستكمال','status':'Open','createdAt':now,'modifiedAt':now,'isDeleted':False}),
('attachments',{'id':'a1','entityType':'item-subitem','entityId':'i1::s1','filename':'child.pdf','mime':'application/pdf','dataUrl':'data:application/pdf;base64,'+base64.b64encode(b'PDF').decode(),'createdAt':now,'modifiedAt':now,'isDeleted':False})]
for store,row in records: st.put(store,row)
out=root/'company.xlsx'; st._write_program_xlsx(out,company_id='c1')
with zipfile.ZipFile(out) as z:
    wb=z.read('xl/workbook.xml').decode('utf-8'); assert wb.count('<sheet ')==2,wb
    assert 'name="البنود"' in wb and 'name="التفتيشات"' in wb
    text=' '.join(z.read(n).decode('utf-8','ignore') for n in z.namelist() if n.endswith('.xml'))
    assert 'ترخيص فرعي' in text and 'معدات الوقاية' in text and '3.2.1' in text
st.close();print('REVIEW FIX QA PASSED')
