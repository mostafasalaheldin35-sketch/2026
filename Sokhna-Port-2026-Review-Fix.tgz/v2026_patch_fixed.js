(function(){
'use strict';
if(window.__sokhna2026)return; window.__sokhna2026=true;
const byId=id=>document.getElementById(id), all=(s,r=document)=>Array.from(r.querySelectorAll(s));
const html=v=>typeof esc==='function'?esc(String(v??'')):String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const isoRe=/^\d{4}-\d{2}-\d{2}$/;
function manualState(v){v=String(v||'').trim().toLowerCase();if(['ok','valid','ساري'].includes(v))return'ok';if(['invalid','not-valid','غير ساري','غيرساري'].includes(v))return'invalid';return''}
function validDate(v){if(!isoRe.test(String(v||'')))return false;const d=new Date(v+'T00:00:00');return !Number.isNaN(d.getTime())}
function today(){return typeof todayStr==='function'?todayStr():new Date().toISOString().slice(0,10)}
function stateOf(rec){
  if(!rec)return'nodate';
  const hasExpiry=validDate(rec.expiryDate);
  if(hasExpiry){
    const exp=new Date(rec.expiryDate+'T00:00:00'), now=new Date(today()+'T00:00:00');
    if(exp<now)return'danger';
    const near=new Date(now.getTime()); near.setDate(near.getDate()+60);
    if(exp<=near)return'warn';
    return'ok';
  }
  const m=manualState(rec.manualStatus); return m||'nodate';
}
function labelOf(st){return st==='danger'?'منتهي':st==='warn'?'قريب من الانتهاء':st==='ok'?'ساري':st==='invalid'?'غير ساري':'غير مكتمل'}
function classOf(st){return st==='invalid'?'danger':st==='nodate'?'nodate':st}
window.itemState=function(it){
  if(Array.isArray(it&&it.subItems)&&it.subItems.length){const c=subSummary(it);if(c.danger||c.invalid)return'danger';if(c.warn)return'warn';if(c.ok)return'ok';return'nodate'}
  return stateOf(it);
};
window.stateLabel=labelOf;
window.stateBadge=function(st){return `<span class="badge ${classOf(st)==='nodate'?'gray':classOf(st)}">${labelOf(st)}</span>`};
window.itemValidityText=function(it){
  if(Array.isArray(it&&it.subItems)&&it.subItems.length){const c=subSummary(it);return `${c.ok} - ${c.warn} - ${c.danger+c.invalid}`}
  const st=stateOf(it); if(st==='danger'){const d=typeof daysRemaining==='function'?daysRemaining(it):null;if(d===0)return'ينتهي اليوم';if(d!==null)return`منتهي منذ ${Math.abs(Number(d||0))} يوم`}
  if(st==='warn'){const d=typeof daysRemaining==='function'?daysRemaining(it):null;return d===null?'قريب من الانتهاء':`متبقي ${Math.max(0,Number(d||0))} يوم`}
  return labelOf(st)
};
window.itemValidityHtml=function(it){
  if(Array.isArray(it&&it.subItems)&&it.subItems.length){const c=subSummary(it);return `<span class="sub-summary" title="ساري - قريب من الانتهاء - منتهي/غير ساري"><b class="sub-ok">${c.ok}</b><i>-</i><b class="sub-warn">${c.warn}</b><i>-</i><b class="sub-bad">${c.danger+c.invalid}</b></span>`}
  const st=stateOf(it);return `<span class="validity-state ${classOf(st)}">${html(window.itemValidityText(it))}</span>`
};
window.statsForCompany=async function(cid){const its=active(await getAll('items')).filter(i=>i.companyId===cid&&i.applicable!==false);const c={total:its.length,danger:0,warn:0,ok:0,nodate:0,invalid:0};for(const i of its)c[stateOf(i)]++;return c};

/* DD/MM/YYYY display backed by one real native calendar. No synthetic "بدون تاريخ" control. */
function syncDateDisplay(native,display){
  if(!native||!display)return;
  display.value=native.value?displayDateValue(native.value):'';
  display.disabled=!!native.disabled;
  display.setAttribute('aria-disabled',native.disabled?'true':'false');
}
function openNativeDatePicker(native){
  if(!native||native.disabled)return;
  try{native.showPicker()}catch(_){try{native.click()}catch(__){}}
}
function repairDateWrap(w){
  if(!w)return;
  all('.v2026-date-clear',w).forEach(x=>x.remove());
  const native=w.querySelector('.v2026-date-native'),display=w.querySelector('.v2026-date-display');
  if(native){native.style.pointerEvents='none';native.tabIndex=-1}
  if(display){display.readOnly=true;display.placeholder='يوم/شهر/سنة';display.onclick=()=>openNativeDatePicker(native);display.onfocus=()=>{};syncDateDisplay(native,display)}
}
function enhanceDate(el){
  if(!el)return;
  const existing=el.closest('.v2026-date-wrap');if(existing){repairDateWrap(existing);return}
  let iso='';try{iso=canonicalDateValue(el.value)||''}catch(_){iso=''}
  /* v4.8.16.9 converted date inputs to text with an own value property. Restore the native input first. */
  try{if(Object.prototype.hasOwnProperty.call(el,'value'))delete el.value}catch(_){}
  el.type='date';el.value=iso;el.dataset.v2026Date='1';el.classList.add('v2026-date-native');el.style.pointerEvents='none';el.tabIndex=-1;
  const wrap=document.createElement('span');wrap.className='v2026-date-wrap';el.parentNode.insertBefore(wrap,el);wrap.appendChild(el);
  const display=document.createElement('input');display.type='text';display.readOnly=true;display.className='v2026-date-display';display.placeholder='يوم/شهر/سنة';display.setAttribute('aria-label','اختيار التاريخ');wrap.appendChild(display);
  display.addEventListener('click',()=>openNativeDatePicker(el));
  el.addEventListener('change',()=>{syncDateDisplay(el,display);el.dispatchEvent(new Event('input',{bubbles:true}))});
  syncDateDisplay(el,display);
}
window.enhanceAllDateInputs=function(root=document){
  all('.v2026-date-wrap',root).forEach(repairDateWrap);
  all('input[data-app-date-input="1"],input[type="date"],input.app-date-input',root).forEach(enhanceDate);
};
function refreshDates(root=document){all('.v2026-date-wrap',root).forEach(repairDateWrap)}

/* Item manual status + child items. Child list mirrors the main item list. */
let subDraft=[],subParent='',editingSubId='';
function subKey(pid,sid){return `${pid}::${sid}`}
function subSummary(item){const out={ok:0,warn:0,danger:0,invalid:0,nodate:0};for(const s of (Array.isArray(item&&item.subItems)?item.subItems:[])){const st=stateOf(s);out[st]=(out[st]||0)+1}return out}
function manualOptions(v){v=manualState(v);return `<option value="">غير مكتمل</option><option value="ok" ${v==='ok'?'selected':''}>ساري</option><option value="invalid" ${v==='invalid'?'selected':''}>غير ساري</option>`}
function ensureSubEditor(){
  const section=byId('subItemsSection');if(!section||byId('subItemEditor'))return;
  const e=document.createElement('div');e.id='subItemEditor';e.className='subitem-editor';e.hidden=true;e.innerHTML=`<div class="subitem-editor-title" id="subItemEditorTitle">تعديل بند فرعي</div><div class="grid2"><label>اسم البند الفرعي *<input id="subEditName"/></label><label>الموقف الحالي<input id="subEditCurrentStatus"/></label></div><div class="grid2"><label>تاريخ الإصدار<input id="subEditIssueDate" type="date" data-app-date-input="1"/></label><label>تاريخ الانتهاء<input id="subEditExpiryDate" type="date" data-app-date-input="1"/></label></div><label style="flex-direction:row;align-items:center;font-weight:400"><input id="subEditNoExpiry" type="checkbox" style="width:auto"/> بدون تاريخ انتهاء</label><label id="subEditManualWrap">الحالة عند عدم وجود تاريخ انتهاء<select id="subEditManualStatus">${manualOptions('')}</select></label><div class="actions"><button type="button" class="primary" id="subEditSave">حفظ البند الفرعي</button><button type="button" class="ghost" id="subEditCancel">إلغاء</button><button type="button" class="danger" id="subEditDelete">حذف</button></div>`;section.appendChild(e);
  const toggle=()=>{const no=byId('subEditNoExpiry').checked;if(no)byId('subEditExpiryDate').value='';byId('subEditExpiryDate').disabled=no;byId('subEditManualStatus').disabled=!no;refreshDates(e)};
  byId('subEditNoExpiry').onchange=toggle;byId('subEditExpiryDate').onchange=()=>{if(byId('subEditExpiryDate').value)byId('subEditNoExpiry').checked=false;toggle()};
  byId('subEditSave').onclick=()=>saveSubEditor();byId('subEditCancel').onclick=()=>closeSubEditor();byId('subEditDelete').onclick=()=>deleteSubEditor();
  enhanceAllDateInputs(e);toggle();
}
function ensureItemEnhancements(){
  const form=byId('itemForm');if(!form)return;
  if(!byId('itemManualStatus')){const no=byId('itemNoExpiry')?.closest('label');const l=document.createElement('label');l.id='itemManualStatusWrap';l.innerHTML=`الحالة اليدوية عند عدم وجود تاريخ انتهاء<select id="itemManualStatus">${manualOptions('')}</select><span class="mini">تُستخدم فقط إذا لم يوجد تاريخ انتهاء.</span>`;no?.after(l)}
  if(!byId('subItemsSection')){const s=document.createElement('section');s.id='subItemsSection';s.className='subitems-section';s.innerHTML='<div class="subitems-head"><h4>البنود الفرعية</h4><button type="button" class="outline small-btn" id="addSubItemBtn">+ إضافة بند فرعي</button></div><div class="subitems-table"><div class="subitems-headrow"><div>مسلسل</div><div>البند</div><div>تاريخ الإصدار</div><div>تاريخ الانتهاء</div><div>المرفقات</div><div>الموقف الحالي</div><div>الحالة</div><div>تعديل</div></div><div id="subItemsList"></div></div>';byId('itemCurrentStatus')?.closest('label')?.before(s)}
  ensureSubEditor();
  const exp=byId('itemExpiryDate'),man=byId('itemManualStatus');
  const toggle=()=>{const noExp=byId('itemNoExpiry')?.checked||!exp?.value;if(man)man.disabled=!noExp;if(exp)exp.disabled=!!byId('itemNoExpiry')?.checked;refreshDates(form)};
  byId('itemNoExpiry')?.addEventListener('change',toggle);exp?.addEventListener('change',toggle);toggle();
  const add=byId('addSubItemBtn');if(add&&!add.dataset.boundFixed){add.dataset.boundFixed='1';add.onclick=()=>{const r={id:uuid(),name:'',issueDate:'',expiryDate:'',noExpiry:true,manualStatus:'',currentStatus:''};subDraft.push(r);renderSubs();openSubEditor(r.id,true)}}
}
function renderSubs(){
  const host=byId('subItemsList');if(!host)return;
  host.innerHTML=subDraft.map((r,idx)=>{const st=stateOf(r);return `<div class="subitem-row" data-subrow="${html(r.id)}"><div>${idx+1}</div><div class="subitem-name-cell">${html(r.name||'—')}</div><div class="classic-date-cell">${r.issueDate?displayDateValue(r.issueDate):'—'}</div><div class="classic-expiry-box">${r.expiryDate?displayDateValue(r.expiryDate):'—'}</div><button type="button" class="classic-item-action" data-subatt="${html(r.id)}">مرفقات</button><div class="subitem-current">${html(r.currentStatus||'—')}</div><div>${stateBadge(st)}</div><button type="button" class="classic-item-action" data-subedit="${html(r.id)}">تعديل</button></div>`}).join('')||'<div class="empty">لا توجد بنود فرعية.</div>';
  host.onclick=e=>{const att=e.target.closest('[data-subatt]');if(att){if(!subParent){toast('احفظ البند الرئيسي أولاً ثم أضف مرفقات البند الفرعي');return}const rec=subDraft.find(x=>x.id===att.dataset.subatt);openAttachments(subKey(subParent,att.dataset.subatt),'item-subitem','مرفقات البند الفرعي: '+(rec?.name||''));return}const edit=e.target.closest('[data-subedit]');if(edit)openSubEditor(edit.dataset.subedit)};
}
function openSubEditor(id,isNew=false){ensureSubEditor();const r=subDraft.find(x=>x.id===id);if(!r)return;editingSubId=id;const e=byId('subItemEditor');e.hidden=false;byId('subItemEditorTitle').textContent=isNew?'إضافة بند فرعي':'تعديل بند فرعي';byId('subEditName').value=r.name||'';byId('subEditCurrentStatus').value=r.currentStatus||'';byId('subEditIssueDate').value=r.issueDate||'';byId('subEditExpiryDate').value=r.expiryDate||'';byId('subEditNoExpiry').checked=!!r.noExpiry||!r.expiryDate;byId('subEditManualStatus').value=manualState(r.manualStatus);const no=byId('subEditNoExpiry').checked;byId('subEditExpiryDate').disabled=no;byId('subEditManualStatus').disabled=!no;enhanceAllDateInputs(e);refreshDates(e);e.scrollIntoView({block:'nearest'})}
function closeSubEditor(){editingSubId='';const e=byId('subItemEditor');if(e)e.hidden=true}
function saveSubEditor(){const r=subDraft.find(x=>x.id===editingSubId);if(!r)return;const name=byId('subEditName').value.trim();if(!name){toast('أدخل اسم البند الفرعي');return}const noExp=byId('subEditNoExpiry').checked,issue=byId('subEditIssueDate').value,expiry=noExp?'':byId('subEditExpiryDate').value;if(issue&&expiry&&expiry<issue){toast('تاريخ الانتهاء لا يمكن أن يسبق تاريخ الإصدار');return}Object.assign(r,{name,issueDate:issue,expiryDate:expiry,noExpiry:noExp,currentStatus:byId('subEditCurrentStatus').value.trim(),manualStatus:expiry?'':manualState(byId('subEditManualStatus').value)});markDirty(byId('itemForm'));renderSubs();closeSubEditor()}
function deleteSubEditor(){if(!editingSubId)return;if(!confirm('حذف البند الفرعي؟'))return;subDraft=subDraft.filter(x=>x.id!==editingSubId);markDirty(byId('itemForm'));renderSubs();closeSubEditor()}
const baseOpenItem=window.openItem; window.openItem=async function(item,forcedCid){const r=await baseOpenItem.apply(this,arguments);ensureItemEnhancements();subParent=item&&item.id||byId('itemId')?.value||'';subDraft=(Array.isArray(item&&item.subItems)?item.subItems:[]).map(x=>({...x,id:x.id||uuid(),noExpiry:x.noExpiry===true||!x.expiryDate}));byId('itemManualStatus').value=manualState(item&&item.manualStatus);renderSubs();closeSubEditor();enhanceAllDateInputs(byId('itemForm'));refreshDates(byId('itemForm'));return r};

/* Company profile: compact rows and one placement dropdown. */
const oldNormalize=window.normalizeCompanyProfileFields;const oldReportPlacement=window.normalizeInspectionReportPlacement;function toReportPlacement(p){return p==='table'?'table':p==='hidden'?'none':'notes'} function fromReportPlacement(p){return p==='table'?'table':p==='none'?'hidden':'below'} window.normalizeInspectionReportPlacement=function(f={}){if(f.companyPlacement)return toReportPlacement(f.companyPlacement);return oldReportPlacement(f)};window.normalizeCompanyProfileFields=function(c={}){return oldNormalize(c).map((f,i)=>{const cp=f.companyPlacement||fromReportPlacement(f.inspectionReportPlacement||oldReportPlacement(f));return {...f,companyPlacement:cp,inspectionReportPlacement:toReportPlacement(cp),showInReport:cp!=='hidden',position:Number(f.position||i+1)}})};
window.renderCompanyProfileFields=function(){
  const host=byId('companyDynamicFieldsList');if(!host)return;const itemOptions=(companyProfileItems||[]).filter(i=>!i.isDeleted&&i.applicable!==false).sort(itemOrderSort).map(i=>`<option value="${html(i.id)}">${html(i.name||'بند')}</option>`).join('');
  const order={table:0,below:1,hidden:2};companyProfileDraft.sort((a,b)=>(order[a.companyPlacement||'table']-order[b.companyPlacement||'table'])||Number(a.position||0)-Number(b.position||0));
  let last='';host.innerHTML=companyProfileDraft.map((f,idx)=>{const p=f.companyPlacement||'table';let group='';if(p!==last){last=p;group=`<div class="company-field-group-title">${p==='table'?'يظهر في الجدول':p==='below'?'يظهر أسفل الجدول':'غير ظاهر'}</div>`}return group+`<div class="company-field-row" data-company-field-card="${idx}"><span class="drag">☰</span><input class="company-field-title-input" data-company-field-label="${idx}" value="${html(f.label||'بند')}"/><div class="company-field-value-compact">${companyFieldInputHtml(f,idx)}</div><select data-company-field-placement="${idx}"><option value="table" ${p==='table'?'selected':''}>في الجدول</option><option value="below" ${p==='below'?'selected':''}>أسفل الجدول</option><option value="hidden" ${p==='hidden'?'selected':''}>مخفي</option></select><select data-company-field-type="${idx}"><option value="text" ${f.type==='text'?'selected':''}>نص</option><option value="textarea" ${f.type==='textarea'?'selected':''}>ملاحظات</option><option value="phone" ${f.type==='phone'?'selected':''}>هاتف</option><option value="contact" ${f.type==='contact'?'selected':''}>اسم + هاتف</option><option value="date" ${f.type==='date'?'selected':''}>تاريخ</option><option value="email" ${f.type==='email'?'selected':''}>بريد</option><option value="number" ${f.type==='number'?'selected':''}>رقم</option></select><select data-company-field-link="${idx}"><option value="">يدوي</option>${itemOptions}</select><button class="ghost small-btn" type="button" data-company-field-up="${idx}">▲</button><button class="ghost small-btn" type="button" data-company-field-down="${idx}">▼</button><button class="danger small-btn" type="button" data-company-field-delete="${idx}">×</button><input type="hidden" data-company-field-prop="${idx}" value="${html(f.linkedProperty||'currentStatus')}"/></div>`}).join('');
  all('[data-company-field-link]',host).forEach(el=>{const i=Number(el.dataset.companyFieldLink);el.value=companyProfileDraft[i]?.linkedItemId||''});enhanceAllDateInputs(host);refreshDates(host)
};
const oldSyncProfile=window.syncCompanyProfileDraftFromDom;window.syncCompanyProfileDraftFromDom=function(){oldSyncProfile();const host=byId('companyDynamicFieldsList');companyProfileDraft.forEach((f,i)=>{const p=host?.querySelector(`[data-company-field-placement="${i}"]`);if(p)f.companyPlacement=p.value||'table';f.inspectionReportPlacement=toReportPlacement(f.companyPlacement||'table');f.showInReport=f.companyPlacement!=='hidden'});let pos={table:0,below:0,hidden:0};for(const f of companyProfileDraft){const p=f.companyPlacement||'table';f.position=++pos[p]}};

/* NCR source selector tied to the current inspection snapshot. */
let ncrRows=[];
function replaceNcrInputs(){for(const id of ['findingRequirement','findingReferenceNo']){const old=byId(id);if(!old||old.tagName==='SELECT')continue;const s=document.createElement('select');s.id=id;s.className=old.className;old.replaceWith(s)}}
async function fillNcrSources(existing){replaceNcrInputs();const req=byId('findingRequirement'),ref=byId('findingReferenceNo');if(!req||!ref)return;const iid=byId('findingInspectionId')?.value,ins=iid?await getOne('inspections',iid):null;ncrRows=ins?await inspectionMastersForRecord(ins):[];ncrRows=(ncrRows||[]).filter(x=>x&&!x.isDeleted).sort((a,b)=>Number(a.position||0)-Number(b.position||0));const oldReq=existing?.requirement||'',oldRef=existing?.referenceNo||'';const opts=['<option value="">اختر من قائمة التفتيش</option>',...ncrRows.map(x=>`<option value="${html(x.id)}">${html((x.referenceNo||'—')+' — '+(x.name||''))}</option>`)].join('');req.innerHTML=opts;ref.innerHTML=opts;let m=ncrRows.find(x=>x.name===oldReq||x.referenceNo===oldRef);if(m){req.value=ref.value=m.id}else if(oldReq||oldRef){for(const s of [req,ref]){const o=document.createElement('option');o.value='__saved__';o.textContent=(oldRef||'—')+' — '+(oldReq||'قيمة محفوظة');s.appendChild(o);s.value='__saved__';s.dataset.savedReq=oldReq;s.dataset.savedRef=oldRef}}const sync=e=>{if(e.target.value==='__saved__')return;req.value=ref.value=e.target.value};req.onchange=sync;ref.onchange=sync}
function selectedNcr(){const id=byId('findingRequirement')?.value;return ncrRows.find(x=>x.id===id)||null}
const oldOpenFinding=window.openFinding;window.openFinding=async function(f=null,inspectionId=null){const r=await oldOpenFinding.apply(this,arguments);await fillNcrSources(f||{});enhanceAllDateInputs(byId('findingForm'));refreshDates(byId('findingForm'));return r};

/* Real autosave first; drafts are fallback only. Navigation waits for an in-flight save. */
let dirtyForms=new Set(),saveTimers=new WeakMap(),savingPromise=null;
function draftKey(f){return 'sokhna-2026-draft-'+f.id}
function snapshot(f){const fields={};all('input,textarea,select',f).forEach(x=>{if(x.id&&x.type!=='file')fields[x.id]=x.type==='checkbox'?x.checked:x.value});return{fields,recordKey:byId(f.id.replace('Form','Id'))?.value||'',savedAt:Date.now()}}
function saveDraft(f){try{localStorage.setItem(draftKey(f),JSON.stringify(snapshot(f)))}catch(_){}}
function clearDraft(f){try{localStorage.removeItem(draftKey(f))}catch(_){}}
function markDirty(f){if(!f)return;dirtyForms.add(f);saveDraft(f);clearTimeout(saveTimers.get(f));saveTimers.set(f,setTimeout(()=>silentSave(f).catch(()=>{}),900))}
async function silentSaveCompany(){syncCompanyProfileDraftFromDom();let id=byId('companyId').value,old=id?await getOne('companies',id):null,name=byId('companyName').value.trim();if(!name)return false;const companySerial=Number(old?.companySerial||0)||await nextCompanySerial();const p={companySerial,name,profileFields:companyProfileDraft.map(f=>({...f,inspectionReportPlacement:toReportPlacement(f.companyPlacement||'table'),showInReport:(f.companyPlacement||'table')!=='hidden'})),profileFieldsVersion:3};for(const d of COMPANY_PROFILE_DEFAULT_FIELDS)p[d.key]=old?.[d.key]??'';for(const f of companyProfileDraft)if(f.key)p[f.key]=f.linkedItemId?companyLinkedFieldValue(f,companyProfileItems):companyFieldDisplayValue(f.value,f.type);const rec=old?stampUpdate(old,p):stampNew(p);await put('companies',rec);if(!id){byId('companyId').value=rec.id;byId('companySerial').value=companySerial;await ensureMasterItemsForCompany(rec.id);companyProfileItems=(await getAll('items')).filter(i=>i.companyId===rec.id)}return true}
async function silentSaveItem(){ensureItemEnhancements();let id=byId('itemId').value,old=id?await getOne('items',id):null,cid=byId('itemCompany').value,name=byId('itemName').value.trim();if(!cid||!name)return false;const expiry=byId('itemNoExpiry').checked?'':byId('itemExpiryDate').value;if(byId('itemIssueDate').value&&expiry&&expiry<byId('itemIssueDate').value)return false;const p={companyId:cid,name,masterItemId:old?.masterItemId||'',masterReferenceNo:old?.masterReferenceNo||'',applicable:byId('itemApplicability').value!=='na',issueDate:byId('itemIssueDate').value,expiryDate:expiry,noExpiry:byId('itemNoExpiry').checked,currentStatus:byId('itemCurrentStatus').value.trim(),manualStatus:expiry?'':manualState(byId('itemManualStatus').value),subItems:subDraft.map((x,i)=>({...x,serial:i+1,manualStatus:x.expiryDate?'':manualState(x.manualStatus)}))};p.position=Number(old?.position||0)||await nextPosition(cid);const rec=old?stampUpdate(old,p):stampNew(p);const input=byId('itemNewAttachments'),files=input?[...input.files]:[],rows=[];for(const f of files)rows.push(stampNew({entityType:'item',entityId:rec.id,filename:f.name||'مرفق',mime:f.type||'',size:Number(f.size||0),dataUrl:await fileData(f)}));await putStoreBatchesAtomic({items:[rec],attachments:rows});if(files.length)input.value='';if(!id){byId('itemId').value=rec.id;subParent=rec.id;byId('itemManageAttachmentsBtn').style.display='block';byId('itemManageAttachmentsBtn').dataset.itemId=rec.id}try{await syncCompanyLinkedProfileValues(cid)}catch(_){}return true}
async function silentSaveInspection(){let id=byId('inspectionId').value,old=id?await getOne('inspections',id):null,companyId=byId('inspectionCompany').value,date=byId('inspectionDate').value;if(!companyId||!date)return false;const data={companyId,date,type:byId('inspectionType').value.trim(),inspectorsList:[1,2,3,4,5,6].map(n=>({name:byId('inspectionInspector'+n).value.trim(),department:byId('inspectionInspectorDept'+n).value.trim()})).filter(x=>x.name||x.department),purpose:byId('inspectionPurpose').value.trim(),notes:byId('inspectionNotes').value.trim(),linkedPreviousInspectionId:byId('inspectionLinkedPrevious')?.value||''};if(!old)Object.assign(data,await buildInspectionSnapshots(companyId));let rec=old?stampUpdate(old,data):stampNew(data);await put('inspections',rec);if(!id)byId('inspectionId').value=rec.id;await rebuildInspectionCodesForCompanyYear(companyId,String(date).slice(0,4));rec=await getOne('inspections',rec.id);byId('inspectionCode').value=rec?.inspectionCode||'';return true}
async function silentSaveFinding(){let id=byId('findingId').value,old=id?await getOne('findings',id):null,iid=byId('findingInspectionId').value;if(!iid||!byId('findingDescription').value.trim())return false;const src=selectedNcr(),req=src?src.name:(byId('findingRequirement').dataset.savedReq||old?.requirement||''),ref=src?src.referenceNo:(byId('findingRequirement').dataset.savedRef||old?.referenceNo||'');const data={inspectionId:iid,no:byId('findingNo').value.trim()||await nextFindingNo(iid),classification:byId('findingClassification').value,requirement:req,referenceNo:ref,description:byId('findingDescription').value.trim(),requiredAction:byId('findingRequiredAction').value.trim(),rootCause:byId('findingRootCause').value.trim(),responsible:byId('findingResponsible').value.trim(),targetDate:byId('findingTargetDate').value,status:byId('findingStatus').value,actualCompletionDate:byId('findingActualCompletionDate').value,notes:byId('findingNotes').value.trim()};const bf=byId('findingBeforePhoto')?.files?.[0],af=byId('findingAfterPhoto')?.files?.[0];if(bf)data.beforePhotoData=await imageToOriginalDataURL(bf);if(af)data.afterPhotoData=await imageToOriginalDataURL(af);const rec=old?stampUpdate(old,data):stampNew(data),input=byId('findingNewAttachments'),files=input?[...input.files]:[],rows=[];for(const f of files)rows.push(stampNew({entityType:'finding',entityId:rec.id,filename:f.name||'مرفق',mime:f.type||'',size:Number(f.size||0),dataUrl:await fileData(f)}));await putStoreBatchesAtomic({findings:[rec],attachments:rows});if(files.length)input.value='';if(!id)byId('findingId').value=rec.id;return true}
async function performSilentSave(f){let ok=false;if(f.id==='companyForm')ok=await silentSaveCompany();else if(f.id==='itemForm')ok=await silentSaveItem();else if(f.id==='inspectionForm')ok=await silentSaveInspection();else if(f.id==='findingForm')ok=await silentSaveFinding();if(ok){dirtyForms.delete(f);clearDraft(f);f.dataset.autosaved='1'}else saveDraft(f);return ok}
async function silentSave(f){if(!f||!dirtyForms.has(f))return true;if(savingPromise)await savingPromise;if(!dirtyForms.has(f))return true;savingPromise=performSilentSave(f).catch(()=>{saveDraft(f);return false});try{return await savingPromise}finally{savingPromise=null}}
async function flushAll(){if(savingPromise)await savingPromise;let failed=false;for(const f of Array.from(dirtyForms))if(!(await silentSave(f)))failed=true;return !failed}
for(const id of ['companyForm','itemForm','inspectionForm','findingForm']){const f=byId(id);if(f){f.addEventListener('input',()=>markDirty(f));f.addEventListener('change',()=>markDirty(f))}}
const baseNavigate=window.navigate;window.navigate=async function(name){const ok=await flushAll();if(!ok)toast('تعذر حفظ بعض التعديلات لأنها غير مكتملة؛ تم الاحتفاظ بها كمسودة');const r=baseNavigate(name);setTimeout(()=>{enhanceAllDateInputs();refreshDates()},0);return r};
window.addEventListener('beforeunload',()=>{for(const f of dirtyForms)saveDraft(f)});

/* Patch normal item save so manual status and subitems are persisted. */
const oldSaveItem=window.saveItem;window.saveItem=async function(e){
  if(!byId('itemManualStatus'))return oldSaveItem.apply(this,arguments);
  e.preventDefault();const btn=byId('itemForm')?.querySelector('button[type="submit"]'),oldText=btn?.textContent||'حفظ البند';if(btn?.disabled)return;
  try{if(btn){btn.disabled=true;btn.textContent='جاري الحفظ...'}const id=byId('itemId').value,old=id?await getOne('items',id):null,cid=byId('itemCompany').value;if(!cid){toast('اختر الشركة');return}const name=byId('itemName').value.trim();if(!name){toast('أدخل اسم البند');return}const noExp=byId('itemNoExpiry').checked,expiry=noExp?'':byId('itemExpiryDate').value;if(byId('itemIssueDate').value&&expiry&&expiry<byId('itemIssueDate').value){toast('تاريخ الانتهاء لا يمكن أن يسبق تاريخ الإصدار');return}const p={companyId:cid,name,masterItemId:old?.masterItemId||'',masterReferenceNo:old?.masterReferenceNo||'',applicable:byId('itemApplicability').value!=='na',issueDate:byId('itemIssueDate').value,expiryDate:expiry,noExpiry:noExp,currentStatus:byId('itemCurrentStatus').value.trim(),manualStatus:expiry?'':manualState(byId('itemManualStatus').value),subItems:subDraft.map((x,i)=>({...x,serial:i+1,manualStatus:x.expiryDate?'':manualState(x.manualStatus)}))};p.position=Number(old?.position||0)||await nextPosition(cid);const rec=old?stampUpdate(old,p):stampNew(p);const files=byId('itemNewAttachments')?[...byId('itemNewAttachments').files]:[],rows=[];for(const f of files)rows.push(stampNew({entityType:'item',entityId:rec.id,filename:f.name||'مرفق',mime:f.type||'',size:Number(f.size||0),dataUrl:await fileData(f)}));await putStoreBatchesAtomic({items:[rec],attachments:rows});dirtyForms.delete(byId('itemForm'));clearDraft(byId('itemForm'));byId('itemDialog').close();await refresh();toast('تم حفظ البند')}catch(err){toast('تعذر حفظ البند: '+(err?.message||'خطأ غير معروف'))}finally{if(btn){btn.disabled=false;btn.textContent=oldText}}};
byId('itemForm')?.removeEventListener('submit',oldSaveItem);byId('itemForm')?.addEventListener('submit',window.saveItem);

/* Child expansion under main item rows: same columns and status colors as main items. */
const oldItemCard=window.itemCard;window.itemCard=function(i,cname='',showCompany=false,displaySeq=''){
  let base=oldItemCard(i,cname,showCompany,displaySeq);if(!Array.isArray(i.subItems)||!i.subItems.length)return base;
  const rows=i.subItems.map((s,n)=>`<div class="sub-expand-row"><div>${n+1}</div><div>${html(s.name||'—')}</div><div>${s.issueDate?displayDateValue(s.issueDate):'—'}</div><div>${s.expiryDate?displayDateValue(s.expiryDate):'—'}</div><button type="button" class="classic-item-action" data-subatt-list="${html(i.id)}::${html(s.id)}">مرفقات</button><div>${html(s.currentStatus||'—')}</div><div>${stateBadge(stateOf(s))}</div><button type="button" class="classic-item-action" data-subedit-list="${html(i.id)}::${html(s.id)}">تعديل</button></div>`).join('');
  return base.replace('</div></div>',`<button type="button" class="sub-toggle" data-subtoggle="${html(i.id)}">⌄</button></div><div class="sub-expand" id="subexpand-${html(i.id)}"><div class="sub-expand-head"><div>مسلسل</div><div>البند</div><div>تاريخ الإصدار</div><div>تاريخ الانتهاء</div><div>المرفقات</div><div>الموقف الحالي</div><div>الحالة</div><div>تعديل</div></div>${rows}</div></div>`)
};
document.addEventListener('click',async e=>{const b=e.target.closest('[data-subtoggle]');if(b){byId('subexpand-'+b.dataset.subtoggle)?.classList.toggle('open');return}const a=e.target.closest('[data-subatt-list]');if(a){const [pid,sid]=a.dataset.subattList.split('::');const item=await getOne('items',pid),sub=(item?.subItems||[]).find(x=>x.id===sid);openAttachments(`${pid}::${sid}`,'item-subitem','مرفقات البند الفرعي: '+(sub?.name||''));return}const ed=e.target.closest('[data-subedit-list]');if(ed){const [pid,sid]=ed.dataset.subeditList.split('::');const item=await getOne('items',pid);if(item){await openItem(item);setTimeout(()=>openSubEditor(sid),0)}}},true);

/* Dashboard/count renderers include manual invalid in the red bucket but keep the exact wording in rows/reports. */
const oldRenderDashboard=window.renderDashboard;window.renderDashboard=async function(){await oldRenderDashboard();const [cs0,its0]=await Promise.all([getAll('companies'),getAll('items')]);const companies=active(cs0),cid=typeof dashboardSelectedCompanyId==='function'?dashboardSelectedCompanyId():'';const items=active(its0).filter(i=>i.applicable!==false&&(!cid||i.companyId===cid));const c={danger:0,invalid:0,warn:0,ok:0,nodate:0};items.forEach(i=>{const st=itemState(i);c[st]=(c[st]||0)+1});byId('dashboardCards').innerHTML=[['إجمالي عدد الشركات',cid?1:companies.length,''],['منتهي / غير ساري',c.danger+c.invalid,'danger-text'],['قريب من الانتهاء',c.warn,'warn-text'],['ساري',c.ok,'ok-text']].map(x=>`<div class="card"><div class="label">${x[0]}</div><div class="num ${x[2]}">${x[1]}</div></div>`).join('')};


/* Normal NCR save must persist the selected checklist name and reference, not option IDs. */
const oldSaveFinding=window.saveFindingForm;
window.saveFindingForm=async function(e){
  if(byId('findingRequirement')?.tagName!=='SELECT')return oldSaveFinding.apply(this,arguments);
  e.preventDefault();const returnView=activeViewName(),btn=byId('findingSaveBtn'),oldText=btn?.textContent||'حفظ بند NCR';if(btn?.disabled)return;
  try{if(btn){btn.disabled=true;btn.textContent='جاري الحفظ...'}const id=byId('findingId').value,old=id?await getOne('findings',id):null,iid=byId('findingInspectionId').value,ins=await getOne('inspections',iid);if(!ins){toast('التفتيش المرتبط غير موجود');return}const src=selectedNcr();const requirement=src?src.name:(byId('findingRequirement').dataset.savedReq||old?.requirement||''),referenceNo=src?src.referenceNo:(byId('findingRequirement').dataset.savedRef||old?.referenceNo||'');let actual=byId('findingActualCompletionDate').value,status=byId('findingStatus').value;if(status==='Closed'&&!actual)actual=today();const data={inspectionId:iid,no:byId('findingNo').value.trim()||await nextFindingNo(iid),classification:byId('findingClassification').value,requirement,referenceNo,description:byId('findingDescription').value.trim(),requiredAction:byId('findingRequiredAction').value.trim(),rootCause:byId('findingRootCause').value.trim(),responsible:byId('findingResponsible').value.trim(),targetDate:byId('findingTargetDate').value,status,actualCompletionDate:actual,closeDate:status==='Closed'?actual:'',completionHistory:Array.isArray(old?.completionHistory)?old.completionHistory:[],notes:byId('findingNotes').value.trim(),beforePhotoData:old?.beforePhotoData||'',afterPhotoData:old?.afterPhotoData||''};const bf=byId('findingBeforePhoto').files[0],af=byId('findingAfterPhoto').files[0];if(bf)data.beforePhotoData=await imageToOriginalDataURL(bf);if(af)data.afterPhotoData=await imageToOriginalDataURL(af);const rec=old?stampUpdate(old,data):stampNew(data),files=byId('findingNewAttachments')?[...byId('findingNewAttachments').files]:[],rows=[];for(const f of files)rows.push(stampNew({entityType:'finding',entityId:rec.id,filename:f.name||'مرفق',mime:f.type||'',size:Number(f.size||0),dataUrl:await fileData(f)}));await putStoreBatchesAtomic({findings:[rec],attachments:rows});dirtyForms.delete(byId('findingForm'));clearDraft(byId('findingForm'));await normalizeNcrSequence(iid);byId('findingDialog').close();await refresh();if(returnView==='inspection-detail')await openInspectionDetail(iid);else if(returnView==='findings')await renderFindings();toast('تم حفظ بند NCR')}catch(err){toast('تعذر حفظ تعديلات NCR: '+(err?.message||'خطأ غير معروف'))}finally{if(btn){btn.disabled=false;btn.textContent=oldText}}
};
byId('findingForm')?.removeEventListener('submit',oldSaveFinding);byId('findingForm')?.addEventListener('submit',window.saveFindingForm);

const oldCompanyCard=window.companyCard;window.companyCard=function(c,s){let x=oldCompanyCard(c,s);if(s?.invalid)x=x.replace(`${s.danger||0} منتهي`,`${Number(s.danger||0)} منتهي`).replace('</div>\n  </div>',`${s.invalid?`<span class="badge danger">${s.invalid} غير ساري</span>`:''}</div>\n  </div>`);return x};
for(const sel of ['companyItemStatusFilter','dashboardItemStateFilter']){const el=byId(sel);if(el){const nd=Array.from(el.options).find(o=>o.value==='nodate');if(nd)nd.textContent='غير مكتمل';if(!Array.from(el.options).some(o=>o.value==='invalid')){const o=document.createElement('option');o.value='invalid';o.textContent='غير ساري';el.appendChild(o)}}}
byId('companyDynamicFieldsList')?.addEventListener('change',e=>{if(e.target.matches('[data-company-field-placement]')){syncCompanyProfileDraftFromDom();renderCompanyProfileFields();markDirty(byId('companyForm'))}});

/* final startup */
ensureItemEnhancements();replaceNcrInputs();enhanceAllDateInputs();refreshDates();all('.v2026-date-clear').forEach(x=>x.remove());
new MutationObserver(()=>{enhanceAllDateInputs();refreshDates()}).observe(document.body,{childList:true,subtree:true});
})();
