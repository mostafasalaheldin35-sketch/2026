from pathlib import Path
import re, shutil
ROOT=Path(__file__).resolve().parents[1]/'buildsrc'
HERE=Path(__file__).resolve().parent
# UI patch reviewed locally in ChatGPT
shutil.copy2(HERE/'v2026_patch_fixed.js', ROOT/'app'/'v2026_patch.js')
html=ROOT/'app'/'index.html'
s=html.read_text(encoding='utf-8')
s=s.replace("const APP_VERSION='4.8.17.0-DESKTOP';","const APP_VERSION='4.8.17.1-DESKTOP';",1)
css=r'''
<style id="v2026-review-fix-style">
.v2026-date-native{pointer-events:none!important;opacity:0!important}
.v2026-date-display{cursor:pointer!important;position:relative!important;z-index:4!important;background:#fff!important}
.v2026-date-display:disabled{background:#f2f4f7!important;color:#667085!important;cursor:not-allowed!important}
.v2026-date-clear{display:none!important}
.subitem-editor{margin-top:10px;padding:12px;border:1px solid #cfd8e3;border-radius:12px;background:#fff}
.subitem-editor[hidden]{display:none!important}.subitem-editor-title{font-weight:800;margin-bottom:9px;color:#0b5592}
.subitems-headrow,.subitem-row,.sub-expand-head,.sub-expand-row{grid-template-columns:55px minmax(180px,1.8fr) 130px 130px 110px minmax(160px,1.4fr) 135px 80px!important}
.subitem-row>div,.sub-expand-row>div{min-width:0}.subitem-name-cell,.subitem-current{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#itemDialog{width:min(98vw,1250px)!important}.subitems-table{overflow-x:auto}
</style>
'''
if 'v2026-review-fix-style' not in s:s=s.replace('</head>',css+'</head>',1)
html.write_text(s,encoding='utf-8',newline='\n')
# Backend corrections
p=ROOT/'backend.py'; b=p.read_text(encoding='utf-8')
b=re.sub(r'^APP_VERSION\s*=\s*"4\.8\.17\.0-DESKTOP"','APP_VERSION = "4.8.17.1-DESKTOP"',b,count=1,flags=re.M)
# Fix general Excel state styling/string consistency after the central state rules changed.
b=b.replace('item_styles[(rr,6)]=7 if state=="منتهية" else 8 if state=="قريبة الانتهاء" else 9 if state=="سارية" else 4', 'item_styles[(rr,6)]=7 if state in ("منتهي","غير ساري") else 8 if state=="قريب من الانتهاء" else 9 if state=="ساري" else 4')
b=b.replace('"بدون انتهاء" if it.get("noExpiry") else self._display_date(it.get("expiryDate"))', 'self._display_date(it.get("expiryDate")) if it.get("expiryDate") else "—"')
# Replace the old 3-sheet per-company branch with the agreed 2-sheet workbook.
old='''        if company_id:\n            return [items_sheet,inspections_sheet,findings_sheet]\n'''
new=r'''        if company_id:
            # Per-company recovery workbook: exactly two sheets, mirroring the program.
            def state_ar(rec: Dict[str, Any]) -> str:
                return self._excel_item_state(rec)
            # Sheet 1: البنود, including child items directly below their parent.
            rows=[["البنود", "", "", "", "", "", "", ""], ["مسلسل","البند","تاريخ الإصدار","تاريخ الانتهاء","المرفقات","الموقف الحالي","الحالة","النوع"]]
            styles={(1,c):12 for c in range(1,9)}; merges=[(1,1,1,8)]
            parent_items=sorted(items,key=lambda x:(int(x.get("position") or 999999),str(x.get("name") or "")))
            for n,it in enumerate(parent_items,1):
                paths=att_paths.get(("item",str(it.get("id"))),[]); link=link_for_rel(paths[0],f"فتح المرفقات ({len(paths)})",folder=True) if paths else "—"
                subs=it.get("subItems") if isinstance(it.get("subItems"),list) else []
                if subs:
                    counts={"ساري":0,"قريب من الانتهاء":0,"منتهي":0,"غير ساري":0,"غير مكتمل":0}
                    for sub in subs: counts[state_ar(sub)]=counts.get(state_ar(sub),0)+1
                    state=f'{counts.get("ساري",0)} - {counts.get("قريب من الانتهاء",0)} - {counts.get("منتهي",0)+counts.get("غير ساري",0)}'
                else: state=state_ar(it)
                rows.append([n,it.get("name","") or "—",self._display_date(it.get("issueDate")),self._display_date(it.get("expiryDate")) if it.get("expiryDate") else "—",link,it.get("currentStatus","") or "—",state,"بند رئيسي"])
                rn=len(rows)
                for c in (1,3,4,5,8): styles[(rn,c)]=11
                styles[(rn,7)]=7 if state in ("منتهي","غير ساري") else 8 if state=="قريب من الانتهاء" else 9 if state=="ساري" else 4
                for sn,sub in enumerate(subs,1):
                    sid=str(sub.get("id") or ""); sk=f'{it.get("id")}::{sid}'; spaths=att_paths.get(("item-subitem",sk),[]); slink=link_for_rel(spaths[0],f"فتح المرفقات ({len(spaths)})",folder=True) if spaths else "—"; ss=state_ar(sub)
                    rows.append([f"{n}.{sn}",f"↳ {sub.get('name') or 'بند فرعي'}",self._display_date(sub.get("issueDate")),self._display_date(sub.get("expiryDate")) if sub.get("expiryDate") else "—",slink,sub.get("currentStatus","") or "—",ss,"بند فرعي"])
                    rn=len(rows)
                    for c in (1,3,4,5,8): styles[(rn,c)]=11
                    styles[(rn,7)]=7 if ss in ("منتهي","غير ساري") else 8 if ss=="قريب من الانتهاء" else 9 if ss=="ساري" else 4
            company_items_sheet={"name":"البنود","rows":rows,"widths":[9,52,17,17,20,40,20,14],"styles":styles,"merges":merges,"header_rows":[2],"freeze":2,"autofilter":True,"autofilter_row":2}
            # Sheet 2: التفتيشات, with each inspection followed immediately by its NCR/observations.
            irows=[["التفتيشات", "", "", "", "", "", "", ""], ["مسلسل","التاريخ","كود التفتيش","النوع","البند / المتطلب","المرجع","الملاحظة / NCR","الحالة / المرفقات"]]
            istyles={(1,c):12 for c in range(1,9)}; imerges=[(1,1,1,8)]
            sorted_ins=sorted(inspections,key=lambda x:(str(x.get("date") or ""),str(x.get("inspectionCode") or x.get("inspectionNo") or "")),reverse=True)
            for n,ins in enumerate(sorted_ins,1):
                ipaths=att_paths.get(("inspection",str(ins.get("id"))),[]); ilink=link_for_rel(ipaths[0],f"مرفقات التفتيش ({len(ipaths)})",folder=True) if ipaths else "—"
                irows.append([n,self._display_date(ins.get("date")),ins.get("inspectionCode") or ins.get("inspectionNo") or "—",ins.get("type","") or "—","—","—",ins.get("notes","") or "—",ilink]); rn=len(irows)
                for c in range(1,9): istyles[(rn,c)]=6 if c in (1,2,3,4) else 11
                fs=sorted([f for f in findings if str(f.get("inspectionId"))==str(ins.get("id"))],key=lambda f:int(str(f.get("no") or "0") or 0))
                for fn,f in enumerate(fs,1):
                    paths=finding_paths(f); flink=link_for_rel(paths[0],f"مرفقات NCR ({len(paths)})",folder=True) if paths else "—"; status=self._excel_status_ar(f.get("status"))
                    irows.append([f"{n}.{fn}","","","NCR",f.get("requirement","") or "—",f.get("referenceNo","") or "—",f.get("description","") or "—",f"{status} | {flink}"]); rn=len(irows); istyles[(rn,8)]=7 if f.get("status") not in ("Closed",) else 9
            company_inspections_sheet={"name":"التفتيشات","rows":irows,"widths":[9,17,22,16,40,18,58,30],"styles":istyles,"merges":imerges,"header_rows":[2],"freeze":2,"autofilter":True,"autofilter_row":2}
            return [company_items_sheet,company_inspections_sheet]
'''
if old not in b: raise SystemExit('review fix: per-company sheet branch missing')
b=b.replace(old,new,1)
p.write_text(b,encoding='utf-8',newline='\n')
